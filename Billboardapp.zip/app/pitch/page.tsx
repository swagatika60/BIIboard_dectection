"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronLeft, ChevronRight } from "lucide-react"

export default function PitchDeckPage() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const slides = [
    {
      title: "Smart Billboard Detection",
      subtitle: "AI-Powered Civic Compliance Solution",
      content: (
        <div className="text-center space-y-6">
          <div className="text-6xl">🏙️</div>
          <p className="text-xl text-gray-600">
            Transforming urban compliance through citizen engagement and smart detection
          </p>
          <div className="bg-gradient-to-r from-cyan-500 to-amber-500 text-white px-6 py-3 rounded-lg inline-block">
            TECHNOVA ESSPL Solution
          </div>
        </div>
      ),
    },
    {
      title: "The Problem",
      subtitle: "Unauthorized billboards plague our cities",
      content: (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-red-50 rounded-lg p-4">
              <div className="text-3xl mb-2">⚠️</div>
              <h3 className="font-semibold text-red-800">Safety Hazards</h3>
              <p className="text-sm text-red-600">Poorly installed billboards cause accidents</p>
            </div>
            <div className="bg-orange-50 rounded-lg p-4">
              <div className="text-3xl mb-2">📏</div>
              <h3 className="font-semibold text-orange-800">Size Violations</h3>
              <p className="text-sm text-orange-600">Oversized displays block visibility</p>
            </div>
            <div className="bg-yellow-50 rounded-lg p-4">
              <div className="text-3xl mb-2">📍</div>
              <h3 className="font-semibold text-yellow-800">Location Issues</h3>
              <p className="text-sm text-yellow-600">Illegal placements near schools, hospitals</p>
            </div>
            <div className="bg-purple-50 rounded-lg p-4">
              <div className="text-3xl mb-2">👮</div>
              <h3 className="font-semibold text-purple-800">Manual Monitoring</h3>
              <p className="text-sm text-purple-600">Limited resources for enforcement</p>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: "Our Solution",
      subtitle: "AI + Citizens = Smart Compliance",
      content: (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-cyan-50 rounded-lg p-4 text-center">
              <div className="text-4xl mb-3">📱</div>
              <h3 className="font-semibold text-cyan-800">Mobile Detection</h3>
              <p className="text-sm text-cyan-600">Instant photo analysis with AI</p>
            </div>
            <div className="bg-amber-50 rounded-lg p-4 text-center">
              <div className="text-4xl mb-3">🤖</div>
              <h3 className="font-semibold text-amber-800">Smart Analysis</h3>
              <p className="text-sm text-amber-600">Automated compliance checking</p>
            </div>
            <div className="bg-green-50 rounded-lg p-4 text-center">
              <div className="text-4xl mb-3">👥</div>
              <h3 className="font-semibold text-green-800">Citizen Power</h3>
              <p className="text-sm text-green-600">Community-driven monitoring</p>
            </div>
          </div>
          <div className="bg-gradient-to-r from-cyan-100 to-amber-100 rounded-lg p-4">
            <p className="text-center font-semibold">
              Real-time detection + Gamified reporting + Instant alerts = Scalable compliance
            </p>
          </div>
        </div>
      ),
    },
    {
      title: "Key Features",
      subtitle: "Comprehensive detection capabilities",
      content: (
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-white text-sm">
                ✓
              </div>
              <span>Structural hazard detection</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-white text-sm">
                ✓
              </div>
              <span>Size & dimension analysis</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-white text-sm">
                ✓
              </div>
              <span>Geolocation compliance</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-white text-sm">
                ✓
              </div>
              <span>Content appropriateness check</span>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center text-white text-sm">
                ✓
              </div>
              <span>Real-time violation alerts</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center text-white text-sm">
                ✓
              </div>
              <span>Citizen gamification system</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center text-white text-sm">
                ✓
              </div>
              <span>Privacy-first data handling</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center text-white text-sm">
                ✓
              </div>
              <span>Municipal dashboard integration</span>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: "Technology Stack",
      subtitle: "Modern, scalable, and secure",
      content: (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-blue-50 rounded-lg p-4 text-center">
            <div className="text-2xl mb-2">⚛️</div>
            <div className="font-semibold">React/Next.js</div>
            <div className="text-xs text-gray-600">Frontend</div>
          </div>
          <div className="bg-green-50 rounded-lg p-4 text-center">
            <div className="text-2xl mb-2">🤖</div>
            <div className="font-semibold">AI Vision</div>
            <div className="text-xs text-gray-600">Detection</div>
          </div>
          <div className="bg-purple-50 rounded-lg p-4 text-center">
            <div className="text-2xl mb-2">🗄️</div>
            <div className="font-semibold">Supabase</div>
            <div className="text-xs text-gray-600">Database</div>
          </div>
          <div className="bg-orange-50 rounded-lg p-4 text-center">
            <div className="text-2xl mb-2">☁️</div>
            <div className="font-semibold">Vercel</div>
            <div className="text-xs text-gray-600">Deployment</div>
          </div>
        </div>
      ),
    },
    {
      title: "Compliance Framework",
      subtitle: "Based on real Indian regulations",
      content: (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-cyan-50 to-amber-50 rounded-lg p-4">
            <h3 className="font-semibold mb-2">Mumbai BMC Policy 2024</h3>
            <ul className="text-sm space-y-1">
              <li>• Maximum size: 40x40 feet</li>
              <li>• Height limit: 100 feet from ground</li>
              <li>• Minimum distance: 70 meters between hoardings</li>
            </ul>
          </div>
          <div className="bg-gradient-to-r from-amber-50 to-green-50 rounded-lg p-4">
            <h3 className="font-semibold mb-2">Ahmedabad Policy 2023</h3>
            <ul className="text-sm space-y-1">
              <li>• Self-signage: Max 25% of facade area</li>
              <li>• Non-reflective materials mandatory</li>
              <li>• No obstruction to pedestrian movement</li>
            </ul>
          </div>
        </div>
      ),
    },
    {
      title: "Gamification & Incentives",
      subtitle: "Engaging citizens through rewards",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Reward System</h3>
            <div className="space-y-2">
              <div className="bg-yellow-50 rounded-lg p-3 flex items-center space-x-3">
                <div className="text-2xl">🏆</div>
                <div>
                  <div className="font-semibold">Leaderboards</div>
                  <div className="text-sm text-gray-600">Monthly top reporters</div>
                </div>
              </div>
              <div className="bg-blue-50 rounded-lg p-3 flex items-center space-x-3">
                <div className="text-2xl">🎖️</div>
                <div>
                  <div className="font-semibold">Achievement Badges</div>
                  <div className="text-sm text-gray-600">Milestone rewards</div>
                </div>
              </div>
              <div className="bg-green-50 rounded-lg p-3 flex items-center space-x-3">
                <div className="text-2xl">💰</div>
                <div>
                  <div className="font-semibold">Point System</div>
                  <div className="text-sm text-gray-600">Redeemable rewards</div>
                </div>
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Engagement Features</h3>
            <div className="space-y-2">
              <div className="bg-purple-50 rounded-lg p-3 flex items-center space-x-3">
                <div className="text-2xl">📊</div>
                <div>
                  <div className="font-semibold">Impact Dashboard</div>
                  <div className="text-sm text-gray-600">Personal contribution metrics</div>
                </div>
              </div>
              <div className="bg-pink-50 rounded-lg p-3 flex items-center space-x-3">
                <div className="text-2xl">🎯</div>
                <div>
                  <div className="font-semibold">Weekly Challenges</div>
                  <div className="text-sm text-gray-600">Themed reporting goals</div>
                </div>
              </div>
              <div className="bg-indigo-50 rounded-lg p-3 flex items-center space-x-3">
                <div className="text-2xl">👥</div>
                <div>
                  <div className="font-semibold">Community Features</div>
                  <div className="text-sm text-gray-600">Social sharing & recognition</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: "Public Dashboard",
      subtitle: "Transparency through data visualization",
      content: (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-lg p-4">
              <h3 className="font-semibold text-red-800 mb-3">🗺️ Violation Heatmaps</h3>
              <ul className="text-sm space-y-1 text-red-700">
                <li>• Real-time violation density</li>
                <li>• Geographic clustering analysis</li>
                <li>• Trend visualization over time</li>
                <li>• Risk zone identification</li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg p-4">
              <h3 className="font-semibold text-blue-800 mb-3">📈 Analytics Dashboard</h3>
              <ul className="text-sm space-y-1 text-blue-700">
                <li>• Compliance rate metrics</li>
                <li>• Response time tracking</li>
                <li>• Citizen engagement stats</li>
                <li>• Municipal performance KPIs</li>
              </ul>
            </div>
          </div>
          <div className="bg-gradient-to-r from-green-100 to-blue-100 rounded-lg p-4 text-center">
            <p className="font-semibold">Promoting transparency and accountability in urban governance</p>
          </div>
        </div>
      ),
    },
    {
      title: "Impact & Benefits",
      subtitle: "Measurable improvements for cities",
      content: (
        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="font-semibold text-lg text-green-800">For Citizens</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm">Safer urban environments</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm">Empowered civic participation</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm">Transparent governance</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm">Gamified engagement rewards</span>
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="font-semibold text-lg text-blue-800">For Authorities</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span className="text-sm">Automated compliance monitoring</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span className="text-sm">Reduced manual inspection costs</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span className="text-sm">Real-time violation alerts</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span className="text-sm">Data-driven policy decisions</span>
              </div>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: "Thank You",
      subtitle: "Building smarter cities together",
      content: (
        <div className="text-center space-y-6">
          <div className="text-6xl">🏙️✨</div>
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-gray-800">Smart Billboard Detection</h3>
            <p className="text-lg text-gray-600">AI-Powered Civic Compliance Solution</p>
            <div className="bg-gradient-to-r from-cyan-500 to-amber-500 text-white px-8 py-4 rounded-lg inline-block">
              <div className="font-bold text-lg">TECHNOVA ESSPL</div>
              <div className="text-sm opacity-90">Transforming Urban Governance</div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4 mt-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-cyan-600">100%</div>
              <div className="text-sm text-gray-600">Automated Detection</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-600">24/7</div>
              <div className="text-sm text-gray-600">Real-time Monitoring</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">∞</div>
              <div className="text-sm text-gray-600">Scalable Solution</div>
            </div>
          </div>
        </div>
      ),
    },
  ]

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-amber-50 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="h-[600px] shadow-xl">
          <CardContent className="p-8 h-full flex flex-col">
            {/* Header */}
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900">{slides[currentSlide].title}</h1>
              <p className="text-lg text-gray-600 mt-2">{slides[currentSlide].subtitle}</p>
            </div>

            {/* Content */}
            <div className="flex-1 flex items-center justify-center">{slides[currentSlide].content}</div>

            {/* Navigation */}
            <div className="flex items-center justify-between mt-8">
              <Button
                onClick={prevSlide}
                variant="outline"
                disabled={currentSlide === 0}
                className="flex items-center space-x-2 bg-transparent"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Previous</span>
              </Button>

              <div className="flex space-x-2">
                {slides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      index === currentSlide ? "bg-cyan-500" : "bg-gray-300"
                    }`}
                  />
                ))}
              </div>

              <Button
                onClick={nextSlide}
                variant="outline"
                disabled={currentSlide === slides.length - 1}
                className="flex items-center space-x-2 bg-transparent"
              >
                <span>Next</span>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>

            {/* Slide counter */}
            <div className="text-center mt-4 text-sm text-gray-500">
              Slide {currentSlide + 1} of {slides.length}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
