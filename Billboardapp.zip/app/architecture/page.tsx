export default function ArchitecturePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-amber-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">System Architecture</h1>

          {/* Architecture Diagram */}
          <div className="bg-gray-50 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">Data Flow & System Components</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Frontend Layer */}
              <div className="bg-cyan-100 rounded-lg p-4">
                <h3 className="font-semibold text-cyan-800 mb-3">Frontend Layer</h3>
                <div className="space-y-2 text-sm">
                  <div className="bg-white rounded p-2">📱 Mobile Web App (PWA)</div>
                  <div className="bg-white rounded p-2">📷 Camera Integration</div>
                  <div className="bg-white rounded p-2">🗺️ Geolocation Services</div>
                  <div className="bg-white rounded p-2">📊 Real-time Dashboard</div>
                  <div className="bg-white rounded p-2">🎮 Gamification UI</div>
                </div>
              </div>

              {/* Processing Layer */}
              <div className="bg-amber-100 rounded-lg p-4">
                <h3 className="font-semibold text-amber-800 mb-3">Processing Layer</h3>
                <div className="space-y-2 text-sm">
                  <div className="bg-white rounded p-2">🤖 AI Detection Engine</div>
                  <div className="bg-white rounded p-2">📏 Size Analysis Module</div>
                  <div className="bg-white rounded p-2">🏗️ Structural Assessment</div>
                  <div className="bg-white rounded p-2">📍 Geofencing Validator</div>
                  <div className="bg-white rounded p-2">⚖️ Compliance Checker</div>
                </div>
              </div>

              {/* Data Layer */}
              <div className="bg-green-100 rounded-lg p-4">
                <h3 className="font-semibold text-green-800 mb-3">Data Layer</h3>
                <div className="space-y-2 text-sm">
                  <div className="bg-white rounded p-2">🗄️ Report Database</div>
                  <div className="bg-white rounded p-2">📋 Compliance Rules DB</div>
                  <div className="bg-white rounded p-2">👥 User Management</div>
                  <div className="bg-white rounded p-2">🏆 Gamification Data</div>
                  <div className="bg-white rounded p-2">📈 Analytics Store</div>
                </div>
              </div>
            </div>
          </div>

          {/* Data Flow */}
          <div className="bg-gray-50 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">Data Flow Process</h2>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <div className="bg-cyan-500 text-white px-4 py-2 rounded-lg">📷 Image Capture</div>
              <div className="text-2xl">→</div>
              <div className="bg-amber-500 text-white px-4 py-2 rounded-lg">🤖 AI Analysis</div>
              <div className="text-2xl">→</div>
              <div className="bg-red-500 text-white px-4 py-2 rounded-lg">⚠️ Violation Detection</div>
              <div className="text-2xl">→</div>
              <div className="bg-green-500 text-white px-4 py-2 rounded-lg">📊 Real-time Alert</div>
              <div className="text-2xl">→</div>
              <div className="bg-purple-500 text-white px-4 py-2 rounded-lg">📈 Dashboard Update</div>
            </div>
          </div>

          {/* Third-party APIs */}
          <div className="bg-gray-50 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Third-party Integrations</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-blue-100 rounded-lg p-4 text-center">
                <div className="text-2xl mb-2">🗺️</div>
                <div className="font-semibold">Google Maps API</div>
                <div className="text-sm text-gray-600">Geolocation & Mapping</div>
              </div>
              <div className="bg-purple-100 rounded-lg p-4 text-center">
                <div className="text-2xl mb-2">🤖</div>
                <div className="font-semibold">AI Vision API</div>
                <div className="text-sm text-gray-600">Image Analysis</div>
              </div>
              <div className="bg-green-100 rounded-lg p-4 text-center">
                <div className="text-2xl mb-2">☁️</div>
                <div className="font-semibold">Cloud Storage</div>
                <div className="text-sm text-gray-600">Image & Data Storage</div>
              </div>
              <div className="bg-orange-100 rounded-lg p-4 text-center">
                <div className="text-2xl mb-2">📱</div>
                <div className="font-semibold">Push Notifications</div>
                <div className="text-sm text-gray-600">Real-time Alerts</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
