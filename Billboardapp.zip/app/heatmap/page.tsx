"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function HeatmapPage() {
  const [selectedTimeframe, setSelectedTimeframe] = useState("week")
  const [selectedViolationType, setSelectedViolationType] = useState("all")

  // Mock heatmap data
  const heatmapData = [
    { area: "Bandra West", violations: 45, severity: "high", lat: 19.0596, lng: 72.8295 },
    { area: "Andheri East", violations: 32, severity: "medium", lat: 19.1136, lng: 72.8697 },
    { area: "Powai", violations: 18, severity: "low", lat: 19.1176, lng: 72.906 },
    { area: "Worli", violations: 28, severity: "medium", lat: 19.0176, lng: 72.8118 },
    { area: "Malad West", violations: 52, severity: "high", lat: 19.1875, lng: 72.8384 },
  ]

  const violationTypes = [
    { id: "all", name: "All Violations", count: 175 },
    { id: "size", name: "Size Violations", count: 68 },
    { id: "location", name: "Location Issues", count: 45 },
    { id: "structural", name: "Structural Hazards", count: 32 },
    { id: "content", name: "Content Issues", count: 30 },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-amber-50 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Public Violation Heatmap</h1>
          <p className="text-gray-600">Real-time visualization of billboard compliance violations across the city</p>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Time Period</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-2">
                {["day", "week", "month", "year"].map((period) => (
                  <Button
                    key={period}
                    variant={selectedTimeframe === period ? "default" : "outline"}
                    onClick={() => setSelectedTimeframe(period)}
                    className="capitalize"
                  >
                    {period}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Violation Type</CardTitle>
            </CardHeader>
            <CardContent>
              <select
                value={selectedViolationType}
                onChange={(e) => setSelectedViolationType(e.target.value)}
                className="w-full p-2 border rounded-lg"
              >
                {violationTypes.map((type) => (
                  <option key={type.id} value={type.id}>
                    {type.name} ({type.count})
                  </option>
                ))}
              </select>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Heatmap Visualization */}
          <div className="lg:col-span-2">
            <Card className="h-[600px]">
              <CardHeader>
                <CardTitle>Violation Density Map</CardTitle>
              </CardHeader>
              <CardContent className="h-full">
                <div className="relative w-full h-full bg-gradient-to-br from-blue-100 to-green-100 rounded-lg overflow-hidden">
                  {/* Mock map with violation hotspots */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="relative w-full h-full">
                      {/* Mumbai outline mockup */}
                      <div className="absolute inset-4 border-2 border-gray-300 rounded-lg bg-white/50">
                        {/* Violation hotspots */}
                        {heatmapData.map((spot, index) => (
                          <div
                            key={index}
                            className={`absolute w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold cursor-pointer transition-transform hover:scale-110 ${
                              spot.severity === "high"
                                ? "bg-red-500"
                                : spot.severity === "medium"
                                  ? "bg-orange-500"
                                  : "bg-yellow-500"
                            }`}
                            style={{
                              left: `${20 + index * 15}%`,
                              top: `${30 + index * 10}%`,
                            }}
                            title={`${spot.area}: ${spot.violations} violations`}
                          >
                            {spot.violations}
                          </div>
                        ))}

                        {/* Legend */}
                        <div className="absolute bottom-4 left-4 bg-white rounded-lg p-3 shadow-lg">
                          <div className="text-sm font-semibold mb-2">Violation Density</div>
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                              <span className="text-xs">High (40+)</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <div className="w-4 h-4 bg-orange-500 rounded-full"></div>
                              <span className="text-xs">Medium (20-39)</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <div className="w-4 h-4 bg-yellow-500 rounded-full"></div>
                              <span className="text-xs">Low (1-19)</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Statistics Panel */}
          <div className="space-y-6">
            {/* Top Violation Areas */}
            <Card>
              <CardHeader>
                <CardTitle>Top Violation Areas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {heatmapData
                    .sort((a, b) => b.violations - a.violations)
                    .map((area, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <div className="font-semibold">{area.area}</div>
                          <div className="text-sm text-gray-600">{area.violations} violations</div>
                        </div>
                        <div
                          className={`w-3 h-3 rounded-full ${
                            area.severity === "high"
                              ? "bg-red-500"
                              : area.severity === "medium"
                                ? "bg-orange-500"
                                : "bg-yellow-500"
                          }`}
                        ></div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center p-4 bg-red-50 rounded-lg">
                    <div className="text-2xl font-bold text-red-600">175</div>
                    <div className="text-sm text-red-700">Total Violations</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">23</div>
                    <div className="text-sm text-orange-700">Critical Issues</div>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">89%</div>
                    <div className="text-sm text-green-700">Response Rate</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-sm">
                    <div className="font-semibold">2 hours ago</div>
                    <div className="text-gray-600">New violation reported in Bandra West</div>
                  </div>
                  <div className="text-sm">
                    <div className="font-semibold">4 hours ago</div>
                    <div className="text-gray-600">Structural hazard resolved in Andheri</div>
                  </div>
                  <div className="text-sm">
                    <div className="font-semibold">6 hours ago</div>
                    <div className="text-gray-600">Size violation flagged in Malad</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
