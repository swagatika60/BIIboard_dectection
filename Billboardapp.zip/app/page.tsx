"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import {
  Camera,
  MapPin,
  Upload,
  AlertTriangle,
  CheckCircle,
  Clock,
  BarChart3,
  Activity,
  Zap,
  FileText,
  Eye,
  Blocks,
  Video,
  Mic,
} from "lucide-react"
import { analyzeImage, type DetectionResult } from "@/lib/ai-detection"
import { BlockchainVerification } from "@/lib/blockchain-verification"
import { PredictiveAnalytics } from "@/lib/predictive-analytics"
import AccessibilityToolbar from "@/components/accessibility-toolbar"

interface BillboardReport {
  id: string
  photos: string[]
  video?: string
  location: string
  coordinates?: { lat: number; lng: number }
  description: string
  status: "pending" | "investigating" | "resolved"
  timestamp: string
  aiAnalysis?: DetectionResult
  priority: "low" | "medium" | "high" | "critical"
  blockchainRecord?: any
  consensusScore?: number
}

export default function BillboardDetectionApp() {
  const [hasConsented, setHasConsented] = useState(false)
  const [showPrivacyModal, setShowPrivacyModal] = useState(false)
  const [isReporting, setIsReporting] = useState(false)
  const [capturedPhotos, setCapturedPhotos] = useState<string[]>([])
  const [isRecording, setIsRecording] = useState(false)
  const [recordedVideo, setRecordedVideo] = useState<string | null>(null)
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const [cameraPermission, setCameraPermission] = useState<"granted" | "denied" | "prompt" | "unknown">("unknown")
  const [cameraError, setCameraError] = useState<string | null>(null)
  const [location, setLocation] = useState("")
  const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null)
  const [description, setDescription] = useState("")
  const [aiAnalysis, setAiAnalysis] = useState<DetectionResult | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const [arMode, setArMode] = useState(false)
  const [arViolations, setArViolations] = useState<any[]>([])
  const [predictiveAlerts, setPredictiveAlerts] = useState<string[]>([])
  const [blockchainRecords, setBlockchainRecords] = useState<any[]>([])

  const [reports, setReports] = useState<BillboardReport[]>([
    {
      id: "1",
      photos: ["/roadside-billboard.png"],
      location: "Main Street & 5th Ave",
      coordinates: { lat: 19.076, lng: 72.8777 },
      description: "Oversized billboard with structural damage blocking traffic view",
      status: "investigating",
      timestamp: "2 hours ago",
      priority: "critical",
      consensusScore: 0.85,
      aiAnalysis: {
        isCompliant: false,
        confidence: 0.89,
        violations: [
          "Oversized dimensions (45x45 feet exceeds 40x40 limit)",
          "Structural deterioration detected",
          "Located within 50m of school zone",
          "Missing permit display",
        ],
        analysis: {
          size: "oversized",
          location: "unauthorized",
          content: "missing_permits",
          visibility: "hazardous",
          structural: "deteriorating",
          zoning: "restricted",
        },
        recommendations: [
          "Immediate structural inspection required",
          "Reduce size to comply with 40x40 feet limit",
          "Relocate away from educational institution",
        ],
        riskLevel: "critical",
        geoCompliance: {
          distanceFromRoad: 15,
          nearSchoolOrHospital: true,
          inCommercialZone: false,
          permitRequired: true,
        },
      },
    },
    {
      id: "2",
      photos: ["/unauthorized-sign.png"],
      location: "Downtown Plaza",
      coordinates: { lat: 19.0825, lng: 72.8811 },
      description: "Poorly installed billboard in residential area",
      status: "resolved",
      timestamp: "1 day ago",
      priority: "high",
      consensusScore: 0.92,
      aiAnalysis: {
        isCompliant: false,
        confidence: 0.94,
        violations: ["Poorly installed mounting system", "Unauthorized residential zone placement"],
        analysis: {
          size: "compliant",
          location: "unauthorized",
          content: "appropriate",
          visibility: "safe",
          structural: "poorly_installed",
          zoning: "residential",
        },
        recommendations: ["Professional installation review required", "Relocate to commercial zone"],
        riskLevel: "high",
        geoCompliance: {
          distanceFromRoad: 25,
          nearSchoolOrHospital: false,
          inCommercialZone: false,
          permitRequired: true,
        },
      },
    },
  ])

  const [activeTab, setActiveTab] = useState("report")
  const [filterStatus, setFilterStatus] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [simpleMode, setSimpleMode] = useState(false)
  const [voiceEnabled, setVoiceEnabled] = useState(false)
  const [showAROverlay, setShowAROverlay] = useState(false)
  const [isDragOver, setIsDragOver] = useState(false)

  const speakText = (text: string) => {
    if (voiceEnabled && "speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text)
      speechSynthesis.speak(utterance)
    }
  }

  const handleVoiceCapture = () => {
    if ("webkitSpeechRecognition" in window) {
      const recognition = new (window as any).webkitSpeechRecognition()
      recognition.lang = "en-US"
      recognition.onresult = (event: any) => {
        const command = event.results[0][0].transcript.toLowerCase()
        if (command.includes("take photo") || command.includes("capture")) {
          capturePhoto()
          speakText("Photo captured successfully")
        } else if (command.includes("submit report")) {
          handleSubmitReport()
          speakText("Report submitted")
        }
      }
      recognition.start()
    }
  }

  useEffect(() => {
    const loadPredictiveData = async () => {
      if (coordinates) {
        const alerts = await PredictiveAnalytics.getPersonalizedAlerts(coordinates)
        setPredictiveAlerts(alerts)
      }
    }
    loadPredictiveData()
  }, [coordinates])

  useEffect(() => {
    const records = BlockchainVerification.getAllRecords()
    setBlockchainRecords(records)
  }, [reports])

  useEffect(() => {
    const consent = localStorage.getItem("billboard-privacy-consent")
    if (consent === "accepted") {
      setHasConsented(true)
    } else {
      setShowPrivacyModal(true)
    }
  }, [])

  const handlePrivacyAccept = () => {
    localStorage.setItem("billboard-privacy-consent", "accepted")
    localStorage.setItem("billboard-consent-date", new Date().toISOString())
    setHasConsented(true)
    setShowPrivacyModal(false)
  }

  const handlePrivacyDecline = () => {
    setShowPrivacyModal(false)
    alert("Privacy consent is required to use the billboard detection features. You can still view public information.")
  }

  const startCamera = async () => {
    try {
      setCameraError(null)
      console.log("[v0] Requesting camera access...")

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
        audio: false,
      })

      console.log("[v0] Camera access granted")
      setCameraStream(stream)
      setCameraPermission("granted")

      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
    } catch (error: any) {
      console.log("[v0] Camera access error:", error.name, error.message)

      if (error.name === "NotAllowedError" || error.name === "PermissionDeniedError") {
        setCameraPermission("denied")
        setCameraError(
          "Camera access was denied. Please use the file upload option below or enable camera permissions in your browser settings.",
        )
      } else if (error.name === "NotFoundError") {
        setCameraPermission("denied")
        setCameraError("No camera found on this device. Please use the file upload option below.")
      } else if (error.name === "NotSupportedError") {
        setCameraPermission("denied")
        setCameraError("Camera is not supported in this browser. Please use the file upload option below.")
      } else {
        setCameraPermission("denied")
        setCameraError("Unable to access camera. Please use the file upload option below.")
      }
    }
  }

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop())
      setCameraStream(null)
    }
    setArMode(false)
  }

  const capturePhoto = () => {
    if (videoRef.current && cameraStream) {
      const canvas = document.createElement("canvas")
      const context = canvas.getContext("2d")

      canvas.width = videoRef.current.videoWidth
      canvas.height = videoRef.current.videoHeight

      if (context) {
        context.drawImage(videoRef.current, 0, 0)
        const photoDataUrl = canvas.toDataURL("image/jpeg", 0.8)
        setCapturedPhotos((prev) => [...prev, photoDataUrl])

        analyzeNewPhoto(photoDataUrl)
      }
    }
  }

  const toggleArMode = () => {
    setArMode(!arMode)
    if (!arMode) {
      // Simulate AR violation detection
      setArViolations([
        {
          id: "ar1",
          type: "Size Violation",
          severity: "high",
          position: { x: 45, y: 35 },
          confidence: 0.87,
        },
        {
          id: "ar2",
          type: "Structural Risk",
          severity: "critical",
          position: { x: 60, y: 25 },
          confidence: 0.92,
        },
      ])
    } else {
      setArViolations([])
    }
  }

  const startRecording = () => {
    if (cameraStream) {
      const mediaRecorder = new MediaRecorder(cameraStream)
      const chunks: BlobPart[] = []

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data)
        }
      }

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: "video/webm" })
        const videoUrl = URL.createObjectURL(blob)
        setRecordedVideo(videoUrl)
      }

      mediaRecorderRef.current = mediaRecorder
      mediaRecorder.start()
      setIsRecording(true)
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
    }
  }

  const handleSimulatedCapture = async () => {
    const simulatedPhoto = "/captured-billboard.png"
    setCapturedPhotos((prev) => [...prev, simulatedPhoto])
    analyzeNewPhoto(simulatedPhoto)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (files && files.length > 0) {
      Array.from(files).forEach((file) => {
        if (file.type.startsWith("image/")) {
          const reader = new FileReader()
          reader.onload = (e) => {
            const photoDataUrl = e.target?.result as string
            setCapturedPhotos((prev) => [...prev, photoDataUrl])
            analyzeNewPhoto(photoDataUrl)
            speakText(`Image uploaded successfully. ${file.name}`)
          }
          reader.readAsDataURL(file)
        }
      })
    }
    if (event.target) {
      event.target.value = ""
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)

    const files = Array.from(e.dataTransfer.files)
    files.forEach((file) => {
      if (file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          const photoDataUrl = e.target?.result as string
          setCapturedPhotos((prev) => [...prev, photoDataUrl])
          analyzeNewPhoto(photoDataUrl)
          speakText(`Image dropped and uploaded successfully. ${file.name}`)
        }
        reader.readAsDataURL(file)
      }
    })
  }

  const analyzeNewPhoto = async (photoUrl: string) => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const coords = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        }
        setCoordinates(coords)
        setLocation(`${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)}`)
      })
    }

    setIsAnalyzing(true)
    try {
      const result = await analyzeImage(photoUrl, coordinates || undefined)
      setAiAnalysis(result)
    } catch (error) {
      console.error("AI analysis failed:", error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  const handleSubmitReport = async () => {
    if (capturedPhotos.length > 0 && location && description) {
      const priority = aiAnalysis?.riskLevel || "low"

      const newReport: BillboardReport = {
        id: Date.now().toString(),
        photos: capturedPhotos,
        video: recordedVideo,
        location,
        coordinates,
        description,
        status: "pending",
        timestamp: "Just now",
        priority,
        aiAnalysis: aiAnalysis || undefined,
        consensusScore: 1.0,
      }

      // Create blockchain record
      const blockchainRecord = await BlockchainVerification.createRecord(newReport)
      newReport.blockchainRecord = blockchainRecord

      setReports([newReport, ...reports])

      setCapturedPhotos([])
      setLocation("")
      setCoordinates(null)
      setDescription("")
      setAiAnalysis(null)
      setRecordedVideo(null)
      setIsReporting(false)
      stopCamera()
    }
  }

  const getStatusIcon = (status: string, priority?: string) => {
    if (priority === "critical") {
      return <Zap className="h-4 w-4" />
    }
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />
      case "investigating":
        return <AlertTriangle className="h-4 w-4" />
      case "resolved":
        return <CheckCircle className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const getStatusColor = (status: string, priority?: string) => {
    if (priority === "critical") {
      return "bg-red-500 text-white"
    }
    if (priority === "high") {
      return "bg-orange-500 text-white"
    }
    switch (status) {
      case "pending":
        return "bg-accent text-accent-foreground"
      case "investigating":
        return "bg-primary text-primary-foreground"
      case "resolved":
        return "bg-green-500 text-white"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const filteredReports = reports.filter((report) => {
    const matchesStatus = filterStatus === "all" || report.status === filterStatus
    const matchesSearch =
      searchQuery === "" ||
      report.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.description.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesStatus && matchesSearch
  })

  const analytics = {
    totalReports: reports.length,
    pendingReports: reports.filter((r) => r.status === "pending").length,
    resolvedReports: reports.filter((r) => r.status === "resolved").length,
    complianceRate: Math.round((reports.filter((r) => r.aiAnalysis?.isCompliant).length / reports.length) * 100) || 0,
    avgConfidence:
      Math.round((reports.reduce((acc, r) => acc + (r.aiAnalysis?.confidence || 0), 0) / reports.length) * 100) || 0,
    avgConsensusScore:
      Math.round((reports.reduce((acc, r) => acc + (r.consensusScore || 0), 0) / reports.length) * 100) || 0,
    verifiedReports: blockchainRecords.filter((r) => r.verified).length,
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50">
      <AccessibilityToolbar />

      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900" id="main-heading">
            Smart Billboard Detection
          </h1>
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="simple-mode"
              checked={simpleMode}
              onChange={(e) => setSimpleMode(e.target.checked)}
              className="rounded"
            />
            <label htmlFor="simple-mode" className="text-sm font-medium">
              Simple Mode
            </label>
          </div>
        </div>

        <nav className="mb-6" role="navigation" aria-label="Main navigation">
          <div className="flex flex-wrap gap-2">
            {[
              { id: "report", label: "Report Billboard", icon: Camera },
              { id: "reports", label: "View Reports", icon: FileText },
              { id: "analytics", label: "Analytics", icon: BarChart3 },
              { id: "live", label: "Live Monitor", icon: Activity },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id)
                  speakText(`Switched to ${tab.label} section`)
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault()
                    setActiveTab(tab.id)
                  }
                }}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 ${
                  activeTab === tab.id
                    ? "bg-cyan-600 text-white shadow-lg"
                    : "bg-white text-gray-700 hover:bg-cyan-50 border border-gray-200"
                }`}
                aria-pressed={activeTab === tab.id}
                aria-describedby={`${tab.id}-description`}
              >
                <tab.icon className="h-4 w-4" aria-hidden="true" />
                {tab.label}
              </button>
            ))}
          </div>

          <button
            onClick={handleVoiceCapture}
            className="mt-2 flex items-center gap-2 px-3 py-1 bg-green-100 text-green-700 rounded-lg text-sm hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-green-500"
            aria-label="Use voice commands to control the app"
          >
            <Mic className="h-4 w-4" />
            Voice Commands
          </button>
        </nav>

        {activeTab === "report" && (
          <div className="space-y-6" role="main" aria-labelledby="report-heading">
            <div className="hidden" id="report-description">
              Report unauthorized billboards by taking photos and providing details
            </div>

            {simpleMode ? (
              <Card className="p-6">
                <CardHeader>
                  <CardTitle className="text-xl">Report a Billboard Problem</CardTitle>
                  <CardDescription>Follow these simple steps to report a billboard violation</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center">
                    <div className="text-6xl mb-4">📸</div>
                    <h3 className="text-lg font-semibold mb-2">Step 1: Take a Photo</h3>
                    <Button
                      onClick={capturePhoto}
                      size="lg"
                      className="w-full max-w-sm"
                      aria-describedby="capture-help"
                    >
                      <Camera className="h-5 w-5 mr-2" />
                      Take Photo of Billboard
                    </Button>
                    <p id="capture-help" className="text-sm text-muted-foreground mt-2">
                      Point your camera at the billboard and tap this button
                    </p>
                  </div>

                  {capturedPhotos.length > 0 && (
                    <div className="text-center">
                      <div className="text-6xl mb-4">✅</div>
                      <h3 className="text-lg font-semibold mb-2">Step 2: Add Details</h3>
                      <div className="space-y-4 max-w-sm mx-auto">
                        <Input
                          placeholder="Where is this billboard? (address)"
                          value={location}
                          onChange={(e) => setLocation(e.target.value)}
                          aria-label="Billboard location"
                        />
                        <Textarea
                          placeholder="What's wrong with this billboard?"
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          rows={3}
                          aria-label="Problem description"
                        />
                        <Button
                          onClick={handleSubmitReport}
                          size="lg"
                          className="w-full"
                          disabled={!location || !description}
                        >
                          Submit Report
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Camera Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Camera className="h-5 w-5" aria-hidden="true" />
                      Camera & Detection
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Camera preview with better accessibility */}
                    <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
                      {cameraStream ? (
                        <video
                          ref={videoRef}
                          autoPlay
                          playsInline
                          muted
                          className="w-full h-full object-cover"
                          aria-label="Live camera preview for billboard detection"
                        />
                      ) : (
                        <div className="flex items-center justify-center h-full text-gray-500">
                          <div className="text-center">
                            <Camera className="h-12 w-12 mx-auto mb-2 opacity-50" />
                            <p>Camera preview will appear here</p>
                          </div>
                        </div>
                      )}

                      {showAROverlay && aiAnalysis && (
                        <div
                          className="absolute inset-0 pointer-events-none"
                          role="img"
                          aria-label="AI detection overlay"
                        >
                          <div className="absolute top-4 left-4 bg-black/70 text-white p-2 rounded text-sm">
                            <div className="flex items-center gap-2">
                              <div
                                className={`w-2 h-2 rounded-full ${
                                  aiAnalysis.riskLevel === "critical"
                                    ? "bg-red-500"
                                    : aiAnalysis.riskLevel === "high"
                                      ? "bg-orange-500"
                                      : aiAnalysis.riskLevel === "medium"
                                        ? "bg-yellow-500"
                                        : "bg-green-500"
                                }`}
                              />
                              <span className="sr-only">Risk level: </span>
                              {aiAnalysis.riskLevel.toUpperCase()} RISK
                            </div>
                          </div>

                          {/* Detection boxes */}
                          <div className="absolute inset-4 border-2 border-cyan-400 rounded-lg">
                            <div className="absolute -top-6 left-0 bg-cyan-400 text-black px-2 py-1 rounded text-xs font-medium">
                              Billboard Detected
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Button
                        onClick={cameraStream ? capturePhoto : startCamera}
                        className="flex-1"
                        aria-describedby="camera-help"
                      >
                        {cameraStream ? (
                          <>
                            <Camera className="h-4 w-4 mr-2" />
                            Capture Photo
                          </>
                        ) : (
                          <>
                            <Video className="h-4 w-4 mr-2" />
                            Start Camera
                          </>
                        )}
                      </Button>

                      <Button
                        variant="outline"
                        onClick={() => setShowAROverlay(!showAROverlay)}
                        aria-pressed={showAROverlay}
                        aria-label="Toggle augmented reality detection overlay"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>

                      <input
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleFileUpload}
                        className="hidden"
                        id="file-upload"
                        aria-label="Upload billboard image from device"
                      />
                      <Button
                        variant="outline"
                        onClick={() => document.getElementById("file-upload")?.click()}
                        aria-describedby="upload-help"
                      >
                        <Upload className="h-4 w-4" />
                      </Button>
                    </div>

                    <div
                      className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
                        isDragOver
                          ? "border-cyan-500 bg-cyan-50"
                          : "border-gray-300 hover:border-cyan-400 hover:bg-gray-50"
                      }`}
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      role="button"
                      tabIndex={0}
                      aria-label="Drag and drop images here or click to upload"
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault()
                          document.getElementById("file-upload")?.click()
                        }
                      }}
                    >
                      <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                      <p className="text-sm font-medium text-gray-700 mb-1">Drop billboard images here</p>
                      <p className="text-xs text-gray-500">
                        or{" "}
                        <button
                          type="button"
                          onClick={() => document.getElementById("file-upload")?.click()}
                          className="text-cyan-600 hover:text-cyan-700 underline focus:outline-none focus:ring-2 focus:ring-cyan-500 rounded"
                        >
                          browse files
                        </button>
                      </p>
                      <p className="text-xs text-gray-400 mt-2">Supports: JPG, PNG, WebP • Multiple files allowed</p>
                    </div>

                    {capturedPhotos.length > 0 && (
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Captured Photos ({capturedPhotos.length})</Label>
                        <div className="grid grid-cols-2 gap-2">
                          {capturedPhotos.map((photo, index) => (
                            <div key={index} className="relative group">
                              <img
                                src={photo || "/placeholder.svg"}
                                alt={`Billboard photo ${index + 1}`}
                                className="w-full h-20 object-cover rounded border"
                              />
                              <button
                                onClick={() => {
                                  setCapturedPhotos((prev) => prev.filter((_, i) => i !== index))
                                  speakText(`Photo ${index + 1} removed`)
                                }}
                                className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity focus:opacity-100 focus:outline-none focus:ring-2 focus:ring-red-500"
                                aria-label={`Remove photo ${index + 1}`}
                              >
                                ×
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="text-xs text-muted-foreground space-y-1">
                      <p id="camera-help">Use camera to capture billboard images for AI analysis</p>
                      <p id="upload-help">Or upload/drag existing photos from your device</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Location and Description Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="h-5 w-5" aria-hidden="true" />
                      Location & Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="Enter address or coordinates"
                        aria-label="Billboard location"
                      />
                      {coordinates && (
                        <p className="text-xs text-muted-foreground mt-1">
                          GPS: {coordinates.lat.toFixed(6)}, {coordinates.lng.toFixed(6)}
                        </p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="description">Violation Description</Label>
                      <Textarea
                        id="description"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="Describe violations: size, structural issues, location problems, missing permits, etc."
                        rows={3}
                        aria-label="Violation description"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Submit Section */}
                <Card>
                  <CardContent>
                    <Button
                      onClick={handleSubmitReport}
                      className="w-full"
                      disabled={capturedPhotos.length === 0 || !location || !description}
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Submit Report ({capturedPhotos.length} photo{capturedPhotos.length !== 1 ? "s" : ""})
                      {aiAnalysis?.riskLevel === "critical" && (
                        <Badge className="ml-2 bg-red-500 text-white">URGENT</Badge>
                      )}
                      <Blocks className="h-4 w-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>

                {(isAnalyzing || aiAnalysis) && (
                  <Card className="border-2 border-cyan-200 bg-cyan-50">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Zap className="h-5 w-5 text-cyan-600" />
                        AI Detection Results
                        {isAnalyzing && (
                          <div className="flex items-center gap-2 text-sm text-cyan-600">
                            <div className="animate-spin rounded-full h-4 w-4 border-2 border-cyan-600 border-t-transparent"></div>
                            Analyzing...
                          </div>
                        )}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {isAnalyzing ? (
                        <div className="text-center py-8">
                          <div className="animate-spin rounded-full h-12 w-12 border-4 border-cyan-600 border-t-transparent mx-auto mb-4"></div>
                          <p className="text-lg font-medium text-cyan-700">Analyzing Billboard...</p>
                          <p className="text-sm text-cyan-600 mt-2">
                            Checking size, location, structural integrity, and compliance
                          </p>
                        </div>
                      ) : aiAnalysis ? (
                        <div className="space-y-4">
                          {/* Compliance Status */}
                          <div className="flex items-center justify-between p-4 rounded-lg bg-white border">
                            <div className="flex items-center gap-3">
                              {aiAnalysis.isCompliant ? (
                                <CheckCircle className="h-8 w-8 text-green-600" />
                              ) : (
                                <AlertTriangle className="h-8 w-8 text-red-600" />
                              )}
                              <div>
                                <h3 className="font-semibold text-lg">
                                  {aiAnalysis.isCompliant ? "Compliant Billboard" : "Violations Detected"}
                                </h3>
                                <p className="text-sm text-gray-600">
                                  Confidence: {Math.round(aiAnalysis.confidence * 100)}%
                                </p>
                              </div>
                            </div>
                            <Badge
                              className={`text-sm px-3 py-1 ${
                                aiAnalysis.riskLevel === "critical"
                                  ? "bg-red-500 text-white"
                                  : aiAnalysis.riskLevel === "high"
                                    ? "bg-orange-500 text-white"
                                    : aiAnalysis.riskLevel === "medium"
                                      ? "bg-yellow-500 text-white"
                                      : "bg-green-500 text-white"
                              }`}
                            >
                              {aiAnalysis.riskLevel.toUpperCase()} RISK
                            </Badge>
                          </div>

                          {/* Violations List */}
                          {aiAnalysis.violations.length > 0 && (
                            <div className="bg-white rounded-lg border p-4">
                              <h4 className="font-semibold text-red-700 mb-3 flex items-center gap-2">
                                <AlertTriangle className="h-5 w-5" />
                                Violations Found ({aiAnalysis.violations.length})
                              </h4>
                              <ul className="space-y-2">
                                {aiAnalysis.violations.map((violation, index) => (
                                  <li key={index} className="flex items-start gap-2 text-sm">
                                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                                    <span className="text-red-700">{violation}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {/* Analysis Details */}
                          <div className="grid grid-cols-2 gap-4">
                            <div className="bg-white rounded-lg border p-3">
                              <h5 className="font-medium text-gray-700 mb-2">Size Analysis</h5>
                              <Badge
                                className={
                                  aiAnalysis.analysis.size === "compliant"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-red-100 text-red-800"
                                }
                              >
                                {aiAnalysis.analysis.size}
                              </Badge>
                            </div>
                            <div className="bg-white rounded-lg border p-3">
                              <h5 className="font-medium text-gray-700 mb-2">Location Status</h5>
                              <Badge
                                className={
                                  aiAnalysis.analysis.location === "authorized"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-red-100 text-red-800"
                                }
                              >
                                {aiAnalysis.analysis.location}
                              </Badge>
                            </div>
                            <div className="bg-white rounded-lg border p-3">
                              <h5 className="font-medium text-gray-700 mb-2">Structural Condition</h5>
                              <Badge
                                className={
                                  aiAnalysis.analysis.structural === "stable"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-red-100 text-red-800"
                                }
                              >
                                {aiAnalysis.analysis.structural}
                              </Badge>
                            </div>
                            <div className="bg-white rounded-lg border p-3">
                              <h5 className="font-medium text-gray-700 mb-2">Zoning Compliance</h5>
                              <Badge
                                className={
                                  aiAnalysis.analysis.zoning === "commercial"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-red-100 text-red-800"
                                }
                              >
                                {aiAnalysis.analysis.zoning}
                              </Badge>
                            </div>
                          </div>

                          {/* Recommendations */}
                          {aiAnalysis.recommendations.length > 0 && (
                            <div className="bg-blue-50 rounded-lg border border-blue-200 p-4">
                              <h4 className="font-semibold text-blue-700 mb-3 flex items-center gap-2">
                                <CheckCircle className="h-5 w-5" />
                                Recommendations
                              </h4>
                              <ul className="space-y-2">
                                {aiAnalysis.recommendations.map((rec, index) => (
                                  <li key={index} className="flex items-start gap-2 text-sm">
                                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                                    <span className="text-blue-700">{rec}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {/* Geolocation Details */}
                          {aiAnalysis.geoCompliance && (
                            <div className="bg-gray-50 rounded-lg border p-4">
                              <h4 className="font-semibold text-gray-700 mb-3">Location Analysis</h4>
                              <div className="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                  <span className="text-gray-600">Distance from road:</span>
                                  <span className="ml-2 font-medium">{aiAnalysis.geoCompliance.distanceFromRoad}m</span>
                                </div>
                                <div>
                                  <span className="text-gray-600">Near school/hospital:</span>
                                  <span
                                    className={`ml-2 font-medium ${aiAnalysis.geoCompliance.nearSchoolOrHospital ? "text-red-600" : "text-green-600"}`}
                                  >
                                    {aiAnalysis.geoCompliance.nearSchoolOrHospital ? "Yes" : "No"}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-gray-600">Commercial zone:</span>
                                  <span
                                    className={`ml-2 font-medium ${aiAnalysis.geoCompliance.inCommercialZone ? "text-green-600" : "text-red-600"}`}
                                  >
                                    {aiAnalysis.geoCompliance.inCommercialZone ? "Yes" : "No"}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-gray-600">Permit required:</span>
                                  <span
                                    className={`ml-2 font-medium ${aiAnalysis.geoCompliance.permitRequired ? "text-orange-600" : "text-green-600"}`}
                                  >
                                    {aiAnalysis.geoCompliance.permitRequired ? "Yes" : "No"}
                                  </span>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      ) : null}
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </div>
        )}

        {/* ... existing code for other tabs ... */}
      </div>

      <a
        href="#main-heading"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-cyan-600 text-white px-4 py-2 rounded-lg z-50"
      >
        Skip to main content
      </a>
    </div>
  )
}
