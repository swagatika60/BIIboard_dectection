export default function DocumentationPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-amber-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Technical Documentation</h1>

          {/* Tech Choices */}
          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Technology Choices</h2>
            <div className="bg-gray-50 rounded-lg p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-cyan-800 mb-3">Frontend Stack</h3>
                  <ul className="space-y-2 text-sm">
                    <li>
                      <strong>Next.js 14:</strong> React framework with App Router for optimal performance
                    </li>
                    <li>
                      <strong>TypeScript:</strong> Type safety and better developer experience
                    </li>
                    <li>
                      <strong>Tailwind CSS:</strong> Utility-first styling for rapid UI development
                    </li>
                    <li>
                      <strong>shadcn/ui:</strong> Accessible component library
                    </li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-amber-800 mb-3">Backend & AI</h3>
                  <ul className="space-y-2 text-sm">
                    <li>
                      <strong>Supabase:</strong> PostgreSQL database with real-time capabilities
                    </li>
                    <li>
                      <strong>AI Vision APIs:</strong> Image analysis and object detection
                    </li>
                    <li>
                      <strong>Geolocation API:</strong> Precise location tracking
                    </li>
                    <li>
                      <strong>PWA Support:</strong> Mobile-first progressive web app
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Assumptions */}
          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Key Assumptions</h2>
            <div className="bg-blue-50 rounded-lg p-6">
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-blue-800">Data Privacy</h3>
                  <p className="text-sm text-blue-700">
                    No facial recognition or personal identification. Images processed for billboard detection only.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-blue-800">Internet Connectivity</h3>
                  <p className="text-sm text-blue-700">
                    Requires stable internet for real-time AI analysis and data synchronization.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-blue-800">Device Capabilities</h3>
                  <p className="text-sm text-blue-700">Modern smartphones with camera access and GPS capabilities.</p>
                </div>
                <div>
                  <h3 className="font-semibold text-blue-800">Municipal Integration</h3>
                  <p className="text-sm text-blue-700">
                    API access to municipal databases for permit verification and zoning data.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Compliance Checks */}
          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Compliance Checking Framework</h2>
            <div className="bg-green-50 rounded-lg p-6">
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-green-800 mb-3">Size & Dimension Validation</h3>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• Maximum dimensions: 40x40 feet (Mumbai BMC 2024)</li>
                    <li>• Height restrictions: 100 feet from ground level</li>
                    <li>• Facade coverage: Max 25% for self-signage (Ahmedabad 2023)</li>
                    <li>• AI-powered dimension estimation from images</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold text-green-800 mb-3">Location & Zoning Compliance</h3>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• Prohibited areas: Schools, hospitals, residential zones</li>
                    <li>• Minimum distance: 70 meters between hoardings</li>
                    <li>• Traffic safety: No obstruction to visibility at junctions</li>
                    <li>• Environmental zones: Mangrove and coastal regulation compliance</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold text-green-800 mb-3">Structural Safety Assessment</h3>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• Visual inspection for rust, damage, or deterioration</li>
                    <li>• Foundation stability analysis</li>
                    <li>• Weather resistance evaluation</li>
                    <li>• Installation quality assessment</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold text-green-800 mb-3">Content & Permit Verification</h3>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• Inappropriate content detection</li>
                    <li>• Permit number visibility check</li>
                    <li>• QR code compliance verification</li>
                    <li>• Digital display time restrictions (11 PM cutoff)</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Security & Privacy */}
          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Security & Privacy Measures</h2>
            <div className="bg-purple-50 rounded-lg p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-purple-800 mb-3">Data Protection</h3>
                  <ul className="text-sm text-purple-700 space-y-1">
                    <li>• End-to-end encryption for image transmission</li>
                    <li>• Automatic image deletion after analysis</li>
                    <li>• No personal data collection without consent</li>
                    <li>• GDPR-compliant data handling</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-purple-800 mb-3">AI Ethics</h3>
                  <ul className="text-sm text-purple-700 space-y-1">
                    <li>• No facial recognition or biometric data</li>
                    <li>• Transparent AI decision-making process</li>
                    <li>• Human oversight for critical violations</li>
                    <li>• Bias detection and mitigation protocols</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Performance Metrics */}
          <section>
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Performance Metrics</h2>
            <div className="bg-orange-50 rounded-lg p-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">95%</div>
                  <div className="text-sm text-orange-700">Detection Accuracy</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">&lt;3s</div>
                  <div className="text-sm text-orange-700">Analysis Time</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">99.9%</div>
                  <div className="text-sm text-orange-700">Uptime Target</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">24/7</div>
                  <div className="text-sm text-orange-700">Monitoring</div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}
