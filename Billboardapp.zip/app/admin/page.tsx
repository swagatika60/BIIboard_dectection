"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Clock, AlertTriangle, CheckCircle, Eye, Brain, Shield, Settings } from "lucide-react"
import { AIAnalysisCard } from "@/components/ai-analysis-card"
import { ComplianceReportCard } from "@/components/compliance-report-card"
import { NotificationCenter } from "@/components/notification-center"
import { LiveMetricsDashboard } from "@/components/live-metrics-dashboard"
import { ComplianceChecker } from "@/lib/compliance-checker"
import type { DetectionResult } from "@/lib/ai-detection"
import type { ComplianceResult } from "@/lib/compliance-checker"

interface BillboardReport {
  id: string
  photo: string
  location: string
  description: string
  status: "pending" | "investigating" | "resolved"
  timestamp: string
  aiAnalysis?: DetectionResult
  complianceResult?: ComplianceResult
  reporterInfo: {
    id: string
    name: string
  }
}

export default function AdminDashboard() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedReport, setSelectedReport] = useState<BillboardReport | null>(null)
  const [complianceChecker] = useState(new ComplianceChecker())

  const [reports] = useState<BillboardReport[]>([
    {
      id: "1",
      photo: "/roadside-billboard.png",
      location: "Main Street & 5th Ave",
      description: "Oversized billboard blocking traffic view",
      status: "investigating",
      timestamp: "2024-01-15T10:30:00Z",
      reporterInfo: { id: "user1", name: "John Doe" },
      aiAnalysis: {
        isCompliant: false,
        confidence: 0.89,
        violations: ["Oversized dimensions", "Blocking sight lines"],
        analysis: { size: "oversized", location: "unauthorized", content: "appropriate", visibility: "hazardous" },
        recommendations: ["Reduce size", "Relocate billboard"],
      },
      complianceResult: {
        isCompliant: false,
        overallScore: 45,
        checks: [
          {
            ruleId: "size-height-limit",
            ruleName: "Maximum Height Restriction",
            passed: false,
            severity: "high",
            message: "Height 28ft exceeds limit of 25ft",
            recommendation: "Reduce billboard height to 25ft or less",
          },
          {
            ruleId: "safety-sight-line",
            ruleName: "Traffic Sight Line Clearance",
            passed: false,
            severity: "critical",
            message: "Billboard obstructs critical traffic sight lines",
            recommendation: "Relocate or resize billboard to clear sight lines",
          },
          {
            ruleId: "permits-display-required",
            ruleName: "Permit Display Requirement",
            passed: false,
            severity: "high",
            message: "Missing or invalid permit display",
            recommendation: "Obtain and display valid billboard permit",
          },
        ],
        criticalViolations: 1,
        highViolations: 2,
        mediumViolations: 0,
        lowViolations: 0,
        recommendations: [
          "Address critical violations immediately to avoid enforcement action",
          "Reduce billboard height to 25ft or less",
          "Relocate or resize billboard to clear sight lines",
          "Obtain and display valid billboard permit",
        ],
      },
    },
    {
      id: "2",
      photo: "/unauthorized-sign.png",
      location: "Downtown Plaza",
      description: "Unauthorized advertising sign in public space",
      status: "resolved",
      timestamp: "2024-01-14T14:20:00Z",
      reporterInfo: { id: "user2", name: "Jane Smith" },
      aiAnalysis: {
        isCompliant: false,
        confidence: 0.94,
        violations: ["Unauthorized location"],
        analysis: { size: "compliant", location: "unauthorized", content: "appropriate", visibility: "safe" },
        recommendations: ["Obtain proper permits"],
      },
      complianceResult: {
        isCompliant: false,
        overallScore: 75,
        checks: [
          {
            ruleId: "permits-display-required",
            ruleName: "Permit Display Requirement",
            passed: false,
            severity: "high",
            message: "Missing or invalid permit display",
            recommendation: "Obtain and display valid billboard permit",
          },
          {
            ruleId: "size-height-limit",
            ruleName: "Maximum Height Restriction",
            passed: true,
            severity: "high",
            message: "Height 20ft is within limit of 25ft",
          },
          {
            ruleId: "safety-sight-line",
            ruleName: "Traffic Sight Line Clearance",
            passed: true,
            severity: "critical",
            message: "Billboard does not obstruct traffic sight lines",
          },
        ],
        criticalViolations: 0,
        highViolations: 1,
        mediumViolations: 0,
        lowViolations: 0,
        recommendations: ["Obtain and display valid billboard permit"],
      },
    },
    {
      id: "3",
      photo: "/captured-billboard.png",
      location: "Highway 101 North",
      description: "Billboard appears to exceed height restrictions",
      status: "pending",
      timestamp: "2024-01-15T16:45:00Z",
      reporterInfo: { id: "user3", name: "Mike Johnson" },
      aiAnalysis: {
        isCompliant: false,
        confidence: 0.76,
        violations: ["Height violation", "Missing permits"],
        analysis: { size: "oversized", location: "authorized", content: "missing_permits", visibility: "safe" },
        recommendations: ["Verify height compliance", "Check permit status"],
      },
      complianceResult: {
        isCompliant: true,
        overallScore: 95,
        checks: [
          {
            ruleId: "size-height-limit",
            ruleName: "Maximum Height Restriction",
            passed: true,
            severity: "high",
            message: "Height 32ft is within limit of 35ft for highway zone",
          },
          {
            ruleId: "permits-display-required",
            ruleName: "Permit Display Requirement",
            passed: true,
            severity: "high",
            message: "Valid permit is properly displayed",
          },
          {
            ruleId: "safety-sight-line",
            ruleName: "Traffic Sight Line Clearance",
            passed: true,
            severity: "critical",
            message: "Billboard does not obstruct traffic sight lines",
          },
        ],
        criticalViolations: 0,
        highViolations: 0,
        mediumViolations: 0,
        lowViolations: 0,
        recommendations: [],
      },
    },
  ])

  const filteredReports = reports.filter((report) => {
    const matchesSearch =
      report.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || report.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const updateReportStatus = (reportId: string, newStatus: "pending" | "investigating" | "resolved") => {
    // In real app, this would update the database
    console.log(`[v0] Updating report ${reportId} to status: ${newStatus}`)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />
      case "investigating":
        return <AlertTriangle className="h-4 w-4" />
      case "resolved":
        return <CheckCircle className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "investigating":
        return "bg-blue-100 text-blue-800"
      case "resolved":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (selectedReport) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Report Details</h1>
              <p className="text-muted-foreground">Report ID: {selectedReport.id}</p>
            </div>
            <div className="flex items-center gap-2">
              <NotificationCenter />
              <Button variant="outline" onClick={() => setSelectedReport(null)}>
                Back to Dashboard
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Evidence Photo</CardTitle>
              </CardHeader>
              <CardContent>
                <img
                  src={selectedReport.photo || "/placeholder.svg"}
                  alt="Billboard evidence"
                  className="w-full h-64 object-cover rounded-lg"
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Report Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Location</label>
                  <p className="text-foreground">{selectedReport.location}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Description</label>
                  <p className="text-foreground">{selectedReport.description}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Reporter</label>
                  <p className="text-foreground">{selectedReport.reporterInfo.name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Submitted</label>
                  <p className="text-foreground">{new Date(selectedReport.timestamp).toLocaleString()}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Status</label>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge className={getStatusColor(selectedReport.status)}>
                      {getStatusIcon(selectedReport.status)}
                      {selectedReport.status}
                    </Badge>
                    <Select onValueChange={(value) => updateReportStatus(selectedReport.id, value as any)}>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Update status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="investigating">Investigating</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {selectedReport.aiAnalysis && (
              <div className="lg:col-span-1">
                <AIAnalysisCard result={selectedReport.aiAnalysis} />
              </div>
            )}

            {selectedReport.complianceResult && (
              <div className="lg:col-span-1">
                <ComplianceReportCard result={selectedReport.complianceResult} />
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Billboard Compliance Dashboard</h1>
              <p className="text-muted-foreground">Monitor and manage billboard compliance reports</p>
            </div>
            <NotificationCenter />
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="reports">All Reports</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="compliance">Compliance Rules</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <LiveMetricsDashboard />

            <Card>
              <CardHeader>
                <CardTitle>Recent Reports</CardTitle>
                <CardDescription>Latest billboard compliance reports requiring attention</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reports.slice(0, 3).map((report) => (
                    <div key={report.id} className="flex items-center gap-4 p-4 border rounded-lg">
                      <img
                        src={report.photo || "/placeholder.svg"}
                        alt="Billboard"
                        className="w-16 h-12 object-cover rounded"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{report.location}</span>
                          <Badge className={getStatusColor(report.status)}>{report.status}</Badge>
                          {report.aiAnalysis && (
                            <Badge
                              variant="outline"
                              className={report.aiAnalysis.isCompliant ? "text-green-600" : "text-red-600"}
                            >
                              <Brain className="h-3 w-3 mr-1" />
                              {report.aiAnalysis.isCompliant ? "Compliant" : "Non-Compliant"}
                            </Badge>
                          )}
                          {report.complianceResult && (
                            <Badge
                              variant="outline"
                              className={report.complianceResult.isCompliant ? "text-green-600" : "text-red-600"}
                            >
                              <Shield className="h-3 w-3 mr-1" />
                              {report.complianceResult.overallScore}%
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{report.description}</p>
                      </div>
                      <Button variant="outline" size="sm" onClick={() => setSelectedReport(report)}>
                        <Eye className="h-4 w-4 mr-2" />
                        View
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Filter Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Search by location or description..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="investigating">Investigating</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-4">
              {filteredReports.map((report) => (
                <Card key={report.id} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4">
                      <img
                        src={report.photo || "/placeholder.svg"}
                        alt="Billboard"
                        className="w-20 h-16 object-cover rounded"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{report.location}</span>
                          <Badge className={getStatusColor(report.status)}>
                            {getStatusIcon(report.status)}
                            {report.status}
                          </Badge>
                          {report.aiAnalysis && (
                            <Badge
                              variant="outline"
                              className={report.aiAnalysis.isCompliant ? "text-green-600" : "text-red-600"}
                            >
                              <Brain className="h-3 w-3 mr-1" />
                              AI: {Math.round(report.aiAnalysis.confidence * 100)}%
                            </Badge>
                          )}
                          {report.complianceResult && (
                            <Badge
                              variant="outline"
                              className={report.complianceResult.isCompliant ? "text-green-600" : "text-red-600"}
                            >
                              <Shield className="h-3 w-3 mr-1" />
                              {report.complianceResult.overallScore}%
                            </Badge>
                          )}
                        </div>
                        <p className="text-muted-foreground mb-2">{report.description}</p>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span>Reporter: {report.reporterInfo.name}</span>
                          <span>•</span>
                          <span>{new Date(report.timestamp).toLocaleDateString()}</span>
                        </div>
                      </div>
                      <Button variant="outline" onClick={() => setSelectedReport(report)}>
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Compliance Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Compliant Billboards</span>
                      <span className="font-bold text-green-600">
                        {reports.filter((r) => r.aiAnalysis?.isCompliant).length}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Non-Compliant Billboards</span>
                      <span className="font-bold text-red-600">
                        {reports.filter((r) => r.aiAnalysis && !r.aiAnalysis.isCompliant).length}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Average AI Confidence</span>
                      <span className="font-bold">
                        {Math.round(
                          (reports.reduce((acc, r) => acc + (r.aiAnalysis?.confidence || 0), 0) / reports.length) * 100,
                        )}
                        %
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Common Violations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>Oversized dimensions</span>
                      <Badge variant="outline">2 reports</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Unauthorized location</span>
                      <Badge variant="outline">2 reports</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Missing permits</span>
                      <Badge variant="outline">1 report</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="compliance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Compliance Rules Management
                </CardTitle>
                <CardDescription>Configure and manage billboard compliance regulations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {complianceChecker.getRules().map((rule) => (
                    <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium">{rule.name}</span>
                          <Badge
                            variant="outline"
                            className={
                              rule.severity === "critical"
                                ? "text-red-600"
                                : rule.severity === "high"
                                  ? "text-orange-600"
                                  : rule.severity === "medium"
                                    ? "text-yellow-600"
                                    : "text-blue-600"
                            }
                          >
                            {rule.severity}
                          </Badge>
                          <Badge variant={rule.enabled ? "default" : "secondary"}>
                            {rule.enabled ? "Enabled" : "Disabled"}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{rule.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">Category: {rule.category}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Configure
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Compliance Zones</CardTitle>
                <CardDescription>Manage zoning regulations and restrictions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {complianceChecker.getZones().map((zone) => (
                    <div key={zone.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium">{zone.name}</span>
                          <Badge variant="outline">{zone.type}</Badge>
                          <Badge variant={zone.allowedBillboards ? "default" : "destructive"}>
                            {zone.allowedBillboards ? "Billboards Allowed" : "Billboards Prohibited"}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Max Height: {zone.maxHeight}ft | Max Area: {zone.maxArea}sq ft | Setback:{" "}
                          {zone.setbackDistance}ft
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        Edit Zone
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
