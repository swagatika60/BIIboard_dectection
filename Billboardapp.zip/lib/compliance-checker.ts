import {
  type ComplianceRule,
  type ComplianceZone,
  type ComplianceCheck,
  type ComplianceResult,
  defaultComplianceRules,
  defaultComplianceZones,
} from "./compliance-rules"
import type { DetectionResult } from "./ai-detection"

export interface BillboardData {
  id: string
  location: {
    address: string
    coordinates: { lat: number; lng: number }
    zoneId: string
  }
  dimensions: {
    height: number // feet
    width: number // feet
    area: number // square feet
  }
  permits: {
    hasValidPermit: boolean
    permitNumber?: string
    expiryDate?: string
    isVisible: boolean
  }
  content: {
    type: string
    description: string
    hasProhibitedContent: boolean
  }
  safety: {
    obstructsSightLines: boolean
    distanceFromIntersection: number // feet
    distanceFromNearestBillboard: number // feet
  }
}

export class ComplianceChecker {
  private rules: ComplianceRule[]
  private zones: ComplianceZone[]

  constructor(customRules?: ComplianceRule[], customZones?: ComplianceZone[]) {
    this.rules = customRules || defaultComplianceRules
    this.zones = customZones || defaultComplianceZones
  }

  async checkCompliance(billboardData: BillboardData, aiAnalysis?: DetectionResult): Promise<ComplianceResult> {
    const checks: ComplianceCheck[] = []
    const zone = this.zones.find((z) => z.id === billboardData.location.zoneId)

    // Run all enabled compliance checks
    for (const rule of this.rules.filter((r) => r.enabled)) {
      const check = await this.runComplianceCheck(rule, billboardData, zone, aiAnalysis)
      if (check) {
        checks.push(check)
      }
    }

    // Calculate overall compliance score and violations
    const totalChecks = checks.length
    const passedChecks = checks.filter((c) => c.passed).length
    const overallScore = totalChecks > 0 ? Math.round((passedChecks / totalChecks) * 100) : 100

    const criticalViolations = checks.filter((c) => !c.passed && c.severity === "critical").length
    const highViolations = checks.filter((c) => !c.passed && c.severity === "high").length
    const mediumViolations = checks.filter((c) => !c.passed && c.severity === "medium").length
    const lowViolations = checks.filter((c) => !c.passed && c.severity === "low").length

    const isCompliant = criticalViolations === 0 && highViolations === 0

    // Generate recommendations
    const recommendations = this.generateRecommendations(checks, zone)

    return {
      isCompliant,
      overallScore,
      checks,
      criticalViolations,
      highViolations,
      mediumViolations,
      lowViolations,
      recommendations,
    }
  }

  private async runComplianceCheck(
    rule: ComplianceRule,
    billboardData: BillboardData,
    zone?: ComplianceZone,
    aiAnalysis?: DetectionResult,
  ): Promise<ComplianceCheck | null> {
    let passed = true
    let message = ""
    let recommendation = ""

    switch (rule.id) {
      case "size-height-limit":
        const maxHeight = zone?.maxHeight || rule.parameters.maxHeight
        passed = billboardData.dimensions.height <= maxHeight + rule.parameters.tolerance
        message = passed
          ? `Height ${billboardData.dimensions.height}ft is within limit of ${maxHeight}ft`
          : `Height ${billboardData.dimensions.height}ft exceeds limit of ${maxHeight}ft`
        recommendation = passed ? undefined : `Reduce billboard height to ${maxHeight}ft or less`
        break

      case "size-area-limit":
        const maxArea = zone?.maxArea || rule.parameters.maxArea
        passed = billboardData.dimensions.area <= maxArea + rule.parameters.tolerance
        message = passed
          ? `Area ${billboardData.dimensions.area}sq ft is within limit of ${maxArea}sq ft`
          : `Area ${billboardData.dimensions.area}sq ft exceeds limit of ${maxArea}sq ft`
        recommendation = passed ? undefined : `Reduce billboard area to ${maxArea}sq ft or less`
        break

      case "location-setback":
        const minSetback = zone?.setbackDistance || rule.parameters.minSetback
        // Simulate setback measurement - in real app would use GPS/mapping data
        const actualSetback = 12 // Mock value
        passed = actualSetback >= minSetback - rule.parameters.tolerance
        message = passed
          ? `Setback distance ${actualSetback}ft meets requirement of ${minSetback}ft`
          : `Setback distance ${actualSetback}ft is less than required ${minSetback}ft`
        recommendation = passed ? undefined : `Move billboard to maintain ${minSetback}ft setback from road`
        break

      case "location-residential-ban":
        passed = !zone || !rule.parameters.prohibitedZones.includes(zone.type)
        message = passed ? "Billboard location is in permitted zone" : `Billboard is prohibited in ${zone?.type} zone`
        recommendation = passed ? undefined : "Relocate billboard to commercial or industrial zone"
        break

      case "permits-display-required":
        passed = billboardData.permits.hasValidPermit && billboardData.permits.isVisible
        message = passed ? "Valid permit is properly displayed" : "Missing or invalid permit display"
        recommendation = passed ? undefined : "Obtain and display valid billboard permit"
        break

      case "safety-sight-line":
        passed = !billboardData.safety.obstructsSightLines
        message = passed
          ? "Billboard does not obstruct traffic sight lines"
          : "Billboard obstructs critical traffic sight lines"
        recommendation = passed ? undefined : "Relocate or resize billboard to clear sight lines"
        break

      case "content-appropriate":
        passed = !billboardData.content.hasProhibitedContent
        message = passed
          ? "Billboard content meets community standards"
          : "Billboard content violates community standards"
        recommendation = passed ? undefined : "Update billboard content to comply with local standards"
        break

      case "location-spacing":
        const minSpacing = rule.parameters.minSpacing
        passed = billboardData.safety.distanceFromNearestBillboard >= minSpacing
        message = passed
          ? `Billboard spacing ${billboardData.safety.distanceFromNearestBillboard}ft meets requirement`
          : `Billboard spacing ${billboardData.safety.distanceFromNearestBillboard}ft is less than required ${minSpacing}ft`
        recommendation = passed ? undefined : `Maintain ${minSpacing}ft minimum distance from other billboards`
        break

      default:
        return null
    }

    return {
      ruleId: rule.id,
      ruleName: rule.name,
      passed,
      severity: rule.severity,
      message,
      recommendation,
    }
  }

  private generateRecommendations(checks: ComplianceCheck[], zone?: ComplianceZone): string[] {
    const recommendations: string[] = []

    // Add specific recommendations from failed checks
    checks
      .filter((c) => !c.passed && c.recommendation)
      .forEach((check) => {
        if (check.recommendation) {
          recommendations.push(check.recommendation)
        }
      })

    // Add general recommendations based on zone
    if (zone && !zone.allowedBillboards) {
      recommendations.push(`Consider relocating to ${zone.type === "residential" ? "commercial" : "permitted"} zone`)
    }

    // Add priority recommendations for critical violations
    const criticalViolations = checks.filter((c) => !c.passed && c.severity === "critical")
    if (criticalViolations.length > 0) {
      recommendations.unshift("Address critical violations immediately to avoid enforcement action")
    }

    return recommendations
  }

  getRules(): ComplianceRule[] {
    return this.rules
  }

  getZones(): ComplianceZone[] {
    return this.zones
  }

  updateRule(ruleId: string, updates: Partial<ComplianceRule>): void {
    const ruleIndex = this.rules.findIndex((r) => r.id === ruleId)
    if (ruleIndex !== -1) {
      this.rules[ruleIndex] = { ...this.rules[ruleIndex], ...updates }
    }
  }

  addRule(rule: ComplianceRule): void {
    this.rules.push(rule)
  }

  removeRule(ruleId: string): void {
    this.rules = this.rules.filter((r) => r.id !== ruleId)
  }
}

// Mock billboard data for testing
export const mockBillboardData: BillboardData = {
  id: "billboard-001",
  location: {
    address: "Main Street & 5th Ave",
    coordinates: { lat: 40.7128, lng: -74.006 },
    zoneId: "commercial-downtown",
  },
  dimensions: {
    height: 28, // Exceeds 25ft limit
    width: 50, // Exceeds 48ft limit
    area: 750, // Exceeds 672sq ft limit
  },
  permits: {
    hasValidPermit: false,
    isVisible: false,
  },
  content: {
    type: "commercial",
    description: "Restaurant advertisement",
    hasProhibitedContent: false,
  },
  safety: {
    obstructsSightLines: true,
    distanceFromIntersection: 50,
    distanceFromNearestBillboard: 250,
  },
}
