export interface BlockchainRecord {
  id: string
  reportId: string
  citizenHash: string // Anonymous citizen identifier
  timestamp: number
  violationData: {
    type: string
    severity: string
    location: { lat: number; lng: number }
    evidence: string // Hash of image/video
  }
  consensusScore: number // Crowd validation score
  verified: boolean
  blockHash: string
}

export class BlockchainVerification {
  private static records: BlockchainRecord[] = []

  static async createRecord(reportData: any): Promise<BlockchainRecord> {
    const record: BlockchainRecord = {
      id: `block_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      reportId: reportData.id,
      citizenHash: this.generateCitizenHash(reportData.location),
      timestamp: Date.now(),
      violationData: {
        type: reportData.violationType,
        severity: reportData.severity,
        location: reportData.location,
        evidence: this.generateEvidenceHash(reportData.photo),
      },
      consensusScore: 1.0, // Initial score
      verified: false,
      blockHash: this.generateBlockHash(),
    }

    this.records.push(record)
    return record
  }

  static async validateWithCrowd(recordId: string, validation: boolean): Promise<number> {
    const record = this.records.find((r) => r.id === recordId)
    if (!record) return 0

    const validationWeight = validation ? 0.1 : -0.1
    record.consensusScore = Math.max(0, Math.min(1, record.consensusScore + validationWeight))

    if (record.consensusScore >= 0.7) {
      record.verified = true
    }

    return record.consensusScore
  }

  private static generateCitizenHash(location: any): string {
    // Anonymous but consistent identifier based on location + time window
    const timeWindow = Math.floor(Date.now() / (1000 * 60 * 60)) // Hour window
    return `citizen_${btoa(`${location.lat}_${location.lng}_${timeWindow}`).substr(0, 8)}`
  }

  private static generateEvidenceHash(photo: string): string {
    return `evidence_${btoa(photo).substr(0, 16)}`
  }

  private static generateBlockHash(): string {
    return `block_${Date.now().toString(36)}_${Math.random().toString(36).substr(2, 8)}`
  }

  static getVerificationStatus(reportId: string): BlockchainRecord | null {
    return this.records.find((r) => r.reportId === reportId) || null
  }

  static getAllRecords(): BlockchainRecord[] {
    return [...this.records]
  }
}
