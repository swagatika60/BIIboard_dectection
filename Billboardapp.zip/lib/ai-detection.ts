export interface DetectionResult {
  isCompliant: boolean
  confidence: number
  violations: string[]
  analysis: {
    size: "compliant" | "oversized" | "undersized"
    location: "authorized" | "unauthorized" | "restricted"
    content: "appropriate" | "inappropriate" | "missing_permits"
    visibility: "safe" | "obstructed" | "hazardous"
    structural: "stable" | "deteriorating" | "hazardous" | "poorly_installed"
    zoning: "commercial" | "residential" | "restricted" | "prohibited"
  }
  recommendations: string[]
  riskLevel: "low" | "medium" | "high" | "critical"
  geoCompliance: {
    distanceFromRoad: number
    nearSchoolOrHospital: boolean
    inCommercialZone: boolean
    permitRequired: boolean
  }
}

export async function analyzeImage(
  imageUrl: string,
  location?: { lat: number; lng: number },
): Promise<DetectionResult> {
  // Simulate AI processing time
  await new Promise((resolve) => setTimeout(resolve, 2000 + Math.random() * 1000))

  // Mock enhanced AI analysis with structural and geolocation checks
  const mockResults: DetectionResult[] = [
    {
      isCompliant: false,
      confidence: 0.89,
      violations: [
        "Oversized dimensions (45x45 feet exceeds 40x40 limit)",
        "Structural deterioration detected",
        "Located within 50m of school zone",
        "Missing permit display",
      ],
      analysis: {
        size: "oversized",
        location: "unauthorized",
        content: "missing_permits",
        visibility: "hazardous",
        structural: "deteriorating",
        zoning: "restricted",
      },
      recommendations: [
        "Immediate structural inspection required",
        "Reduce size to comply with 40x40 feet limit",
        "Relocate away from educational institution",
        "Display valid permit prominently",
      ],
      riskLevel: "critical",
      geoCompliance: {
        distanceFromRoad: 15,
        nearSchoolOrHospital: true,
        inCommercialZone: false,
        permitRequired: true,
      },
    },
    {
      isCompliant: false,
      confidence: 0.94,
      violations: [
        "Poorly installed mounting system",
        "Unauthorized residential zone placement",
        "Exceeds height limit (110 feet from ground)",
      ],
      analysis: {
        size: "compliant",
        location: "unauthorized",
        content: "appropriate",
        visibility: "safe",
        structural: "poorly_installed",
        zoning: "residential",
      },
      recommendations: [
        "Professional installation review required",
        "Relocate to designated commercial advertising zone",
        "Reduce height to comply with 100 feet limit",
      ],
      riskLevel: "high",
      geoCompliance: {
        distanceFromRoad: 25,
        nearSchoolOrHospital: false,
        inCommercialZone: false,
        permitRequired: true,
      },
    },
    {
      isCompliant: true,
      confidence: 0.96,
      violations: [],
      analysis: {
        size: "compliant",
        location: "authorized",
        content: "appropriate",
        visibility: "safe",
        structural: "stable",
        zoning: "commercial",
      },
      recommendations: ["Billboard fully compliant with all regulations"],
      riskLevel: "low",
      geoCompliance: {
        distanceFromRoad: 80,
        nearSchoolOrHospital: false,
        inCommercialZone: true,
        permitRequired: false,
      },
    },
  ]

  return mockResults[Math.floor(Math.random() * mockResults.length)]
}

export function getComplianceColor(isCompliant: boolean): string {
  return isCompliant ? "text-green-600" : "text-red-600"
}

export function getComplianceBadgeColor(isCompliant: boolean): string {
  return isCompliant ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
}

export function getRiskLevelColor(riskLevel: string): string {
  switch (riskLevel) {
    case "low":
      return "text-green-600"
    case "medium":
      return "text-yellow-600"
    case "high":
      return "text-orange-600"
    case "critical":
      return "text-red-600"
    default:
      return "text-gray-600"
  }
}

export function getRiskLevelBadgeColor(riskLevel: string): string {
  switch (riskLevel) {
    case "low":
      return "bg-green-100 text-green-800"
    case "medium":
      return "bg-yellow-100 text-yellow-800"
    case "high":
      return "bg-orange-100 text-orange-800"
    case "critical":
      return "bg-red-100 text-red-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}
