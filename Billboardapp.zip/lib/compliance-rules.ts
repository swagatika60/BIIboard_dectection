export interface ComplianceRule {
  id: string
  name: string
  category: "size" | "location" | "content" | "permits" | "safety"
  description: string
  enabled: boolean
  parameters: {
    [key: string]: any
  }
  severity: "low" | "medium" | "high" | "critical"
}

export interface ComplianceZone {
  id: string
  name: string
  type: "commercial" | "residential" | "industrial" | "restricted" | "highway"
  allowedBillboards: boolean
  maxHeight: number // in feet
  maxWidth: number // in feet
  maxArea: number // in square feet
  setbackDistance: number // in feet from road
  permitRequired: boolean
  restrictions: string[]
}

export interface ComplianceCheck {
  ruleId: string
  ruleName: string
  passed: boolean
  severity: "low" | "medium" | "high" | "critical"
  message: string
  recommendation?: string
}

export interface ComplianceResult {
  isCompliant: boolean
  overallScore: number // 0-100
  checks: ComplianceCheck[]
  criticalViolations: number
  highViolations: number
  mediumViolations: number
  lowViolations: number
  recommendations: string[]
}

// Default compliance rules for billboard regulations
export const defaultComplianceRules: ComplianceRule[] = [
  {
    id: "size-height-limit",
    name: "Maximum Height Restriction",
    category: "size",
    description: "Billboard height must not exceed local zoning limits",
    enabled: true,
    parameters: {
      maxHeight: 25, // feet
      tolerance: 2, // feet
    },
    severity: "high",
  },
  {
    id: "size-area-limit",
    name: "Maximum Area Restriction",
    category: "size",
    description: "Billboard area must comply with local regulations",
    enabled: true,
    parameters: {
      maxArea: 672, // square feet (typical 14x48 billboard)
      tolerance: 50, // square feet
    },
    severity: "high",
  },
  {
    id: "location-setback",
    name: "Road Setback Distance",
    category: "location",
    description: "Billboard must maintain minimum distance from roadway",
    enabled: true,
    parameters: {
      minSetback: 15, // feet
      tolerance: 2, // feet
    },
    severity: "medium",
  },
  {
    id: "location-residential-ban",
    name: "Residential Zone Prohibition",
    category: "location",
    description: "Billboards prohibited in residential zones",
    enabled: true,
    parameters: {
      prohibitedZones: ["residential"],
    },
    severity: "critical",
  },
  {
    id: "permits-display-required",
    name: "Permit Display Requirement",
    category: "permits",
    description: "Valid permit must be visibly displayed on billboard",
    enabled: true,
    parameters: {
      requireVisible: true,
      maxAge: 365, // days
    },
    severity: "high",
  },
  {
    id: "safety-sight-line",
    name: "Traffic Sight Line Clearance",
    category: "safety",
    description: "Billboard must not obstruct traffic sight lines",
    enabled: true,
    parameters: {
      minClearance: 8, // feet from intersection
      intersectionRadius: 100, // feet
    },
    severity: "critical",
  },
  {
    id: "content-appropriate",
    name: "Content Appropriateness",
    category: "content",
    description: "Billboard content must comply with community standards",
    enabled: true,
    parameters: {
      prohibitedContent: ["adult", "tobacco", "alcohol-near-schools"],
      schoolDistance: 500, // feet
    },
    severity: "medium",
  },
  {
    id: "location-spacing",
    name: "Billboard Spacing Requirements",
    category: "location",
    description: "Minimum distance required between billboards",
    enabled: true,
    parameters: {
      minSpacing: 300, // feet
      sameOwner: 150, // feet if same owner
    },
    severity: "low",
  },
  {
    id: "size-mumbai-standard",
    name: "Mumbai BMC Size Standard (40x40 feet)",
    category: "size",
    description: "Billboard must not exceed 40 feet by 40 feet as per Mumbai BMC Draft Policy 2024",
    enabled: true,
    parameters: {
      maxWidth: 40, // feet - Mumbai BMC standard
      maxHeight: 40, // feet - Mumbai BMC standard
      maxArea: 1600, // square feet (40x40)
      tolerance: 2, // feet tolerance
    },
    severity: "high",
  },
  {
    id: "height-ground-clearance",
    name: "Ground Height Restriction (100 feet max)",
    category: "size",
    description: "Billboard height from ground level must not exceed 100 feet (Mumbai BMC 2024)",
    enabled: true,
    parameters: {
      maxGroundHeight: 100, // feet from ground level
      tolerance: 5, // feet
    },
    severity: "critical",
  },
  {
    id: "location-prohibited-areas",
    name: "Prohibited Location Areas",
    category: "location",
    description: "No hoardings over footpaths, roadways, traffic islands, building terraces, compound walls",
    enabled: true,
    parameters: {
      prohibitedAreas: [
        "footpaths",
        "roadways",
        "traffic_islands",
        "building_terraces",
        "compound_walls",
        "construction_fences",
        "glass_facades_over_50_percent",
      ],
    },
    severity: "critical",
  },
  {
    id: "spacing-70m-rule",
    name: "70 Meter Spacing Rule",
    category: "location",
    description: "New hoardings must be at least 70 meters away from existing ones (Mumbai BMC 2024)",
    enabled: true,
    parameters: {
      minSpacing: 70, // meters between billboards
      tolerance: 5, // meters
    },
    severity: "high",
  },
  {
    id: "digital-time-restrictions",
    name: "Digital Display Time Restrictions",
    category: "content",
    description: "Digital displays must be switched off by 11 PM (Mumbai BMC 2024)",
    enabled: true,
    parameters: {
      offTime: "23:00", // 11 PM
      onTime: "06:00", // 6 AM
      noFlickering: true,
    },
    severity: "medium",
  },
  {
    id: "permit-quarterly-renewal",
    name: "Quarterly Permit Renewal",
    category: "permits",
    description: "Permit renewals required every three months (Mumbai BMC 2024)",
    enabled: true,
    parameters: {
      renewalPeriod: 90, // days (3 months)
      gracePeriod: 15, // days after expiry
      requireVisible: true,
    },
    severity: "high",
  },
  {
    id: "ahmedabad-facade-limit",
    name: "Ahmedabad Facade Area Limit (25%)",
    category: "size",
    description: "Self-signage must not exceed 25% of building facade area (Ahmedabad 2023)",
    enabled: true,
    parameters: {
      maxFacadePercentage: 25, // percent of building facade
      nonReflective: true,
    },
    severity: "medium",
  },
  {
    id: "safety-restricted-zones",
    name: "Safety Restricted Zones",
    category: "safety",
    description: "Prohibited near high-tension wires, airport areas, mangrove/coastal zones",
    enabled: true,
    parameters: {
      restrictedZones: ["high_tension_wires", "airport_funnel_areas", "mangrove_zones", "coastal_regulation_zones"],
      requiresNOC: ["airport_areas"],
    },
    severity: "critical",
  },
  {
    id: "pedestrian-safety",
    name: "Pedestrian Movement Safety",
    category: "safety",
    description: "Cannot obstruct pedestrian movement, fire escapes, doors, or windows (Ahmedabad 2023)",
    enabled: true,
    parameters: {
      noObstruction: ["pedestrian_paths", "fire_escapes", "doors", "windows"],
      minClearance: 2.5, // meters for pedestrian clearance
    },
    severity: "high",
  },
  {
    id: "environmental-protection",
    name: "Environmental Protection",
    category: "location",
    description: "Signboards not permitted on trees or shrubs (Ahmedabad 2023)",
    enabled: true,
    parameters: {
      prohibitedOn: ["trees", "shrubs", "natural_vegetation"],
      environmentalBuffer: 10, // meters from protected areas
    },
    severity: "medium",
  },
]

// Default compliance zones for billboard regulations
export const defaultComplianceZones: ComplianceZone[] = [
  {
    id: "commercial-downtown",
    name: "Downtown Commercial District",
    type: "commercial",
    allowedBillboards: true,
    maxHeight: 25,
    maxWidth: 48,
    maxArea: 672,
    setbackDistance: 15,
    permitRequired: true,
    restrictions: ["No flashing lights", "No digital displays after 10 PM"],
  },
  {
    id: "highway-corridor",
    name: "Highway Commercial Corridor",
    type: "highway",
    allowedBillboards: true,
    maxHeight: 35,
    maxWidth: 60,
    maxArea: 1200,
    setbackDistance: 25,
    permitRequired: true,
    restrictions: ["Must be at least 300 feet from other billboards"],
  },
  {
    id: "residential-suburban",
    name: "Suburban Residential",
    type: "residential",
    allowedBillboards: false,
    maxHeight: 0,
    maxWidth: 0,
    maxArea: 0,
    setbackDistance: 0,
    permitRequired: false,
    restrictions: ["Billboards prohibited in residential zones"],
  },
  {
    id: "industrial-park",
    name: "Industrial Park",
    type: "industrial",
    allowedBillboards: true,
    maxHeight: 30,
    maxWidth: 50,
    maxArea: 800,
    setbackDistance: 20,
    permitRequired: true,
    restrictions: ["Business-related content only"],
  },
  {
    id: "mumbai-commercial",
    name: "Mumbai Commercial District (BMC 2024)",
    type: "commercial",
    allowedBillboards: true,
    maxHeight: 40, // feet - BMC standard
    maxWidth: 40, // feet - BMC standard
    maxArea: 1600, // square feet (40x40)
    setbackDistance: 15, // feet
    permitRequired: true,
    restrictions: [
      "No digital displays after 11 PM",
      "70 meter spacing from other billboards",
      "Quarterly permit renewal required",
      "No flickering advertisements",
    ],
  },
  {
    id: "ahmedabad-commercial",
    name: "Ahmedabad Commercial Zone (Policy 2023)",
    type: "commercial",
    allowedBillboards: true,
    maxHeight: 30, // feet
    maxWidth: 50, // feet
    maxArea: 1500, // square feet
    setbackDistance: 12, // feet
    permitRequired: true,
    restrictions: [
      "Max 25% of building facade area",
      "Non-reflective materials only",
      "Cannot obstruct pedestrian movement",
      "No installation on trees or shrubs",
    ],
  },
  {
    id: "highway-corridor-india",
    name: "National Highway Corridor",
    type: "highway",
    allowedBillboards: true,
    maxHeight: 35, // feet
    maxWidth: 60, // feet
    maxArea: 2100, // square feet
    setbackDistance: 25, // feet
    permitRequired: true,
    restrictions: [
      "Minimum 70 meters between billboards",
      "No obstruction of traffic sight lines",
      "Structural safety certification required",
      "State highway authority approval needed",
    ],
  },
  {
    id: "residential-prohibited",
    name: "Residential Areas (All Cities)",
    type: "residential",
    allowedBillboards: false,
    maxHeight: 0,
    maxWidth: 0,
    maxArea: 0,
    setbackDistance: 0,
    permitRequired: false,
    restrictions: [
      "Billboards completely prohibited in residential zones",
      "Only building name plates and directional signs allowed",
      "Maximum 2 sq ft for name plates",
    ],
  },
  {
    id: "haryana-municipal",
    name: "Haryana Municipal Areas (Bye-laws 2022)",
    type: "commercial",
    allowedBillboards: true,
    maxHeight: 30, // feet
    maxWidth: 45, // feet
    maxArea: 1350, // square feet
    setbackDistance: 20, // feet
    permitRequired: true,
    restrictions: [
      "Haryana Municipal Corporation Advertisement Bye-laws 2022 compliance",
      "Local municipal approval required",
      "Regular structural safety inspections",
    ],
  },
  {
    id: "protected-heritage",
    name: "Heritage and Protected Areas",
    type: "restricted",
    allowedBillboards: false,
    maxHeight: 0,
    maxWidth: 0,
    maxArea: 0,
    setbackDistance: 100, // feet buffer from heritage sites
    permitRequired: false,
    restrictions: [
      "No advertising within 100 feet of heritage monuments",
      "Archaeological Survey of India (ASI) clearance required",
      "State heritage committee approval needed",
    ],
  },
]
