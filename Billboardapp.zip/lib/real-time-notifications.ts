export interface Notification {
  id: string
  type: "new_report" | "status_update" | "critical_violation" | "compliance_alert" | "system_update"
  title: string
  message: string
  timestamp: string
  priority: "low" | "medium" | "high" | "critical"
  read: boolean
  actionUrl?: string
  reportId?: string
  data?: any
}

export interface LiveMetrics {
  totalReports: number
  pendingReports: number
  criticalViolations: number
  complianceRate: number
  activeUsers: number
  lastUpdated: string
}

export class RealTimeNotificationService {
  private notifications: Notification[] = []
  private listeners: ((notifications: Notification[]) => void)[] = []
  private metricsListeners: ((metrics: LiveMetrics) => void)[] = []
  private currentMetrics: LiveMetrics = {
    totalReports: 3,
    pendingReports: 1,
    criticalViolations: 1,
    complianceRate: 67,
    activeUsers: 12,
    lastUpdated: new Date().toISOString(),
  }

  constructor() {
    // Simulate real-time updates
    this.startSimulation()
  }

  private startSimulation() {
    // Simulate new notifications every 30-60 seconds
    setInterval(
      () => {
        this.simulateNewNotification()
      },
      45000 + Math.random() * 30000,
    )

    // Update metrics every 10 seconds
    setInterval(() => {
      this.updateMetrics()
    }, 10000)
  }

  private simulateNewNotification() {
    const mockNotifications: Omit<Notification, "id" | "timestamp" | "read">[] = [
      {
        type: "new_report",
        title: "New Billboard Report",
        message: "A new billboard violation has been reported on Oak Street",
        priority: "medium",
        actionUrl: "/admin",
        reportId: "new-" + Date.now(),
      },
      {
        type: "critical_violation",
        title: "Critical Safety Violation",
        message: "Billboard blocking traffic sight lines detected - immediate action required",
        priority: "critical",
        actionUrl: "/admin",
        reportId: "critical-" + Date.now(),
      },
      {
        type: "status_update",
        title: "Report Status Updated",
        message: "Billboard report #1234 has been resolved",
        priority: "low",
        actionUrl: "/admin",
        reportId: "1234",
      },
      {
        type: "compliance_alert",
        title: "Compliance Check Complete",
        message: "AI analysis detected 3 regulatory violations requiring review",
        priority: "high",
        actionUrl: "/admin",
      },
      {
        type: "system_update",
        title: "System Update",
        message: "Billboard detection accuracy improved to 94%",
        priority: "low",
      },
    ]

    const randomNotification = mockNotifications[Math.floor(Math.random() * mockNotifications.length)]
    this.addNotification(randomNotification)
  }

  private updateMetrics() {
    // Simulate small changes in metrics
    const changes = {
      totalReports: Math.random() > 0.8 ? 1 : 0,
      pendingReports: Math.random() > 0.7 ? (Math.random() > 0.5 ? 1 : -1) : 0,
      criticalViolations: Math.random() > 0.9 ? (Math.random() > 0.5 ? 1 : -1) : 0,
      activeUsers: Math.floor((Math.random() - 0.5) * 4), // -2 to +2
    }

    this.currentMetrics = {
      ...this.currentMetrics,
      totalReports: Math.max(0, this.currentMetrics.totalReports + changes.totalReports),
      pendingReports: Math.max(0, this.currentMetrics.pendingReports + changes.pendingReports),
      criticalViolations: Math.max(0, this.currentMetrics.criticalViolations + changes.criticalViolations),
      activeUsers: Math.max(1, this.currentMetrics.activeUsers + changes.activeUsers),
      lastUpdated: new Date().toISOString(),
    }

    // Recalculate compliance rate
    this.currentMetrics.complianceRate = Math.max(
      0,
      Math.min(
        100,
        Math.round(
          ((this.currentMetrics.totalReports - this.currentMetrics.criticalViolations) /
            this.currentMetrics.totalReports) *
            100,
        ),
      ),
    )

    this.notifyMetricsListeners()
  }

  addNotification(notification: Omit<Notification, "id" | "timestamp" | "read">) {
    const newNotification: Notification = {
      ...notification,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      read: false,
    }

    this.notifications.unshift(newNotification)

    // Keep only last 50 notifications
    if (this.notifications.length > 50) {
      this.notifications = this.notifications.slice(0, 50)
    }

    this.notifyListeners()

    // Show browser notification for high/critical priority
    if (notification.priority === "high" || notification.priority === "critical") {
      this.showBrowserNotification(newNotification)
    }
  }

  private showBrowserNotification(notification: Notification) {
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(notification.title, {
        body: notification.message,
        icon: "/favicon.ico",
        tag: notification.id,
      })
    }
  }

  requestNotificationPermission() {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission()
    }
  }

  subscribe(callback: (notifications: Notification[]) => void) {
    this.listeners.push(callback)
    // Immediately call with current notifications
    callback(this.notifications)

    return () => {
      this.listeners = this.listeners.filter((listener) => listener !== callback)
    }
  }

  subscribeToMetrics(callback: (metrics: LiveMetrics) => void) {
    this.metricsListeners.push(callback)
    // Immediately call with current metrics
    callback(this.currentMetrics)

    return () => {
      this.metricsListeners = this.metricsListeners.filter((listener) => listener !== callback)
    }
  }

  private notifyListeners() {
    this.listeners.forEach((callback) => callback(this.notifications))
  }

  private notifyMetricsListeners() {
    this.metricsListeners.forEach((callback) => callback(this.currentMetrics))
  }

  markAsRead(notificationId: string) {
    const notification = this.notifications.find((n) => n.id === notificationId)
    if (notification) {
      notification.read = true
      this.notifyListeners()
    }
  }

  markAllAsRead() {
    this.notifications.forEach((n) => (n.read = true))
    this.notifyListeners()
  }

  getUnreadCount(): number {
    return this.notifications.filter((n) => !n.read).length
  }

  getNotifications(): Notification[] {
    return this.notifications
  }

  getCurrentMetrics(): LiveMetrics {
    return this.currentMetrics
  }
}

// Global instance
export const notificationService = new RealTimeNotificationService()
