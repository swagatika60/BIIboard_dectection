import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, CheckCircle, Eye, MapPin, Ruler, FileText } from "lucide-react"
import { type DetectionResult, getComplianceBadgeColor } from "@/lib/ai-detection"

interface AIAnalysisCardProps {
  result: DetectionResult
  isLoading?: boolean
}

export function AIAnalysisCard({ result, isLoading }: AIAnalysisCardProps) {
  if (isLoading) {
    return (
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary"></div>
            AI Analysis in Progress
          </CardTitle>
          <CardDescription>Analyzing image for compliance violations...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="h-4 bg-muted rounded animate-pulse"></div>
            <div className="h-4 bg-muted rounded animate-pulse w-3/4"></div>
            <div className="h-4 bg-muted rounded animate-pulse w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  const getAnalysisIcon = (category: string, status: string) => {
    const iconClass = "h-4 w-4"
    switch (category) {
      case "size":
        return <Ruler className={iconClass} />
      case "location":
        return <MapPin className={iconClass} />
      case "content":
        return <FileText className={iconClass} />
      case "visibility":
        return <Eye className={iconClass} />
      default:
        return <AlertTriangle className={iconClass} />
    }
  }

  const getStatusColor = (status: string) => {
    if (status.includes("compliant") || status === "appropriate" || status === "authorized" || status === "safe") {
      return "text-green-600"
    }
    return "text-red-600"
  }

  return (
    <Card className={`border-2 ${result.isCompliant ? "border-green-200" : "border-red-200"}`}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {result.isCompliant ? (
              <CheckCircle className="h-5 w-5 text-green-600" />
            ) : (
              <AlertTriangle className="h-5 w-5 text-red-600" />
            )}
            AI Compliance Analysis
          </div>
          <Badge className={getComplianceBadgeColor(result.isCompliant)}>
            {result.isCompliant ? "Compliant" : "Non-Compliant"}
          </Badge>
        </CardTitle>
        <CardDescription>Confidence: {Math.round(result.confidence * 100)}%</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Progress value={result.confidence * 100} className="h-2" />

        {!result.isCompliant && result.violations.length > 0 && (
          <div>
            <h4 className="font-medium text-red-600 mb-2">Violations Detected:</h4>
            <ul className="space-y-1">
              {result.violations.map((violation, index) => (
                <li key={index} className="text-sm text-muted-foreground flex items-center gap-2">
                  <AlertTriangle className="h-3 w-3 text-red-500 flex-shrink-0" />
                  {violation}
                </li>
              ))}
            </ul>
          </div>
        )}

        <div>
          <h4 className="font-medium mb-2">Detailed Analysis:</h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            {Object.entries(result.analysis).map(([category, status]) => (
              <div key={category} className="flex items-center gap-2">
                {getAnalysisIcon(category, status)}
                <span className="capitalize text-muted-foreground">{category}:</span>
                <span className={getStatusColor(status)}>{status.replace("_", " ")}</span>
              </div>
            ))}
          </div>
        </div>

        {result.recommendations.length > 0 && (
          <div>
            <h4 className="font-medium mb-2">Recommendations:</h4>
            <ul className="space-y-1">
              {result.recommendations.map((rec, index) => (
                <li key={index} className="text-sm text-muted-foreground">
                  • {rec}
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
