import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, CheckCircle, XCircle, Shield, AlertCircle } from "lucide-react"
import type { ComplianceResult } from "@/lib/compliance-checker"

interface ComplianceReportCardProps {
  result: ComplianceResult
  isLoading?: boolean
}

export function ComplianceReportCard({ result, isLoading }: ComplianceReportCardProps) {
  if (isLoading) {
    return (
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary"></div>
            Compliance Check in Progress
          </CardTitle>
          <CardDescription>Validating against regulatory requirements...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="h-4 bg-muted rounded animate-pulse"></div>
            <div className="h-4 bg-muted rounded animate-pulse w-3/4"></div>
            <div className="h-4 bg-muted rounded animate-pulse w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600"
    if (score >= 70) return "text-yellow-600"
    return "text-red-600"
  }

  const getScoreProgressColor = (score: number) => {
    if (score >= 90) return "bg-green-500"
    if (score >= 70) return "bg-yellow-500"
    return "bg-red-500"
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return <XCircle className="h-4 w-4 text-red-600" />
      case "high":
        return <AlertTriangle className="h-4 w-4 text-orange-600" />
      case "medium":
        return <AlertCircle className="h-4 w-4 text-yellow-600" />
      case "low":
        return <AlertCircle className="h-4 w-4 text-blue-600" />
      default:
        return <CheckCircle className="h-4 w-4 text-green-600" />
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-100 text-red-800"
      case "high":
        return "bg-orange-100 text-orange-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-green-100 text-green-800"
    }
  }

  return (
    <Card className={`border-2 ${result.isCompliant ? "border-green-200" : "border-red-200"}`}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            Regulatory Compliance Check
          </div>
          <Badge className={result.isCompliant ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
            {result.isCompliant ? "Compliant" : "Non-Compliant"}
          </Badge>
        </CardTitle>
        <CardDescription>
          Compliance Score: <span className={getScoreColor(result.overallScore)}>{result.overallScore}%</span>
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Overall Compliance</span>
            <span className={`text-sm font-bold ${getScoreColor(result.overallScore)}`}>{result.overallScore}%</span>
          </div>
          <Progress value={result.overallScore} className="h-3" />
        </div>

        {/* Violation Summary */}
        {(result.criticalViolations > 0 ||
          result.highViolations > 0 ||
          result.mediumViolations > 0 ||
          result.lowViolations > 0) && (
          <div>
            <h4 className="font-medium mb-3">Violation Summary:</h4>
            <div className="grid grid-cols-2 gap-3">
              {result.criticalViolations > 0 && (
                <div className="flex items-center gap-2">
                  <XCircle className="h-4 w-4 text-red-600" />
                  <span className="text-sm">Critical: {result.criticalViolations}</span>
                </div>
              )}
              {result.highViolations > 0 && (
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-orange-600" />
                  <span className="text-sm">High: {result.highViolations}</span>
                </div>
              )}
              {result.mediumViolations > 0 && (
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-yellow-600" />
                  <span className="text-sm">Medium: {result.mediumViolations}</span>
                </div>
              )}
              {result.lowViolations > 0 && (
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-blue-600" />
                  <span className="text-sm">Low: {result.lowViolations}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Detailed Checks */}
        <div>
          <h4 className="font-medium mb-3">Detailed Compliance Checks:</h4>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {result.checks.map((check, index) => (
              <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                <div className="flex-shrink-0 mt-0.5">
                  {check.passed ? <CheckCircle className="h-4 w-4 text-green-600" /> : getSeverityIcon(check.severity)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium">{check.ruleName}</span>
                    {!check.passed && (
                      <Badge variant="outline" className={getSeverityColor(check.severity)}>
                        {check.severity}
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{check.message}</p>
                  {check.recommendation && <p className="text-xs text-blue-600 mt-1">💡 {check.recommendation}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recommendations */}
        {result.recommendations.length > 0 && (
          <div>
            <h4 className="font-medium mb-2">Compliance Recommendations:</h4>
            <ul className="space-y-1">
              {result.recommendations.map((rec, index) => (
                <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
