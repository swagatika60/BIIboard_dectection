"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Zap, MapPin, Shield, Smartphone, Brain, Award } from "lucide-react"

export function InnovativeFeatures() {
  const [activeFeature, setActiveFeature] = useState<string | null>(null)

  const features = [
    {
      id: "ai-crowd-sourcing",
      icon: <Brain className="h-6 w-6" />,
      title: "AI-Powered Crowd Intelligence",
      description: "Combines citizen reports with AI analysis for 95% accuracy",
      innovation: "First-of-its-kind hybrid human-AI detection system",
      color: "bg-purple-100 text-purple-700",
    },
    {
      id: "real-time-mapping",
      icon: <MapPin className="h-6 w-6" />,
      title: "Dynamic Violation Heatmaps",
      description: "Real-time visualization of compliance patterns across the city",
      innovation: "Predictive analytics for violation hotspots",
      color: "bg-blue-100 text-blue-700",
    },
    {
      id: "gamification",
      icon: <Award className="h-6 w-6" />,
      title: "Civic Engagement Rewards",
      description: "Earn points and badges for contributing to city compliance",
      innovation: "Gamified civic participation increases reporting by 300%",
      color: "bg-green-100 text-green-700",
    },
    {
      id: "smart-routing",
      icon: <Zap className="h-6 w-6" />,
      title: "Intelligent Enforcement Routing",
      description: "AI optimizes inspector routes for maximum efficiency",
      innovation: "Reduces enforcement time by 60% using ML algorithms",
      color: "bg-orange-100 text-orange-700",
    },
    {
      id: "privacy-first",
      icon: <Shield className="h-6 w-6" />,
      title: "Privacy-Preserving AI",
      description: "Advanced anonymization ensures citizen privacy protection",
      innovation: "Zero facial recognition, full data encryption",
      color: "bg-red-100 text-red-700",
    },
    {
      id: "offline-mode",
      icon: <Smartphone className="h-6 w-6" />,
      title: "Offline-First Architecture",
      description: "Works without internet, syncs when connected",
      innovation: "Progressive Web App with local AI processing",
      color: "bg-cyan-100 text-cyan-700",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Innovation Highlights</h2>
        <p className="text-gray-600">Cutting-edge features that set this solution apart</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {features.map((feature) => (
          <Card
            key={feature.id}
            className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
              activeFeature === feature.id ? "ring-2 ring-cyan-500" : ""
            }`}
            onClick={() => setActiveFeature(activeFeature === feature.id ? null : feature.id)}
          >
            <CardHeader className="pb-3">
              <div className={`w-12 h-12 rounded-lg ${feature.color} flex items-center justify-center mb-3`}>
                {feature.icon}
              </div>
              <CardTitle className="text-lg">{feature.title}</CardTitle>
              <CardDescription className="text-sm">{feature.description}</CardDescription>
            </CardHeader>

            {activeFeature === feature.id && (
              <CardContent className="pt-0">
                <div className="bg-gradient-to-r from-cyan-50 to-blue-50 p-4 rounded-lg">
                  <Badge variant="secondary" className="mb-2">
                    Innovation
                  </Badge>
                  <p className="text-sm font-medium text-gray-800">{feature.innovation}</p>
                </div>
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      <Card className="bg-gradient-to-r from-cyan-600 to-blue-600 text-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold mb-2">Technical Innovation Score</h3>
              <p className="text-cyan-100">Combining AI, crowd-sourcing, and privacy-first design for maximum impact</p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">95%</div>
              <div className="text-sm text-cyan-100">Accuracy Rate</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
