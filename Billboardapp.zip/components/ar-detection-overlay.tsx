"use client"

export default function ARDetectionOverlay({
  isActive,
  violations,
  onViolationSelect,
}: {
  isActive: boolean
  violations: Array<{
    id: string
    type: string
    severity: "low" | "medium" | "high" | "critical"
    position: { x: number; y: number }
    confidence: number
  }>
  onViolationSelect: (violation: any) => void
}) {
  if (!isActive) return null

  return (
    <div className="absolute inset-0 pointer-events-none">
      {violations.map((violation) => (
        <div
          key={violation.id}
          className={`absolute pointer-events-auto cursor-pointer transform -translate-x-1/2 -translate-y-1/2 ${
            violation.severity === "critical" ? "animate-pulse" : ""
          }`}
          style={{
            left: `${violation.position.x}%`,
            top: `${violation.position.y}%`,
          }}
          onClick={() => onViolationSelect(violation)}
        >
          <div
            className={`
            w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-bold
            ${
              violation.severity === "critical"
                ? "bg-red-500 border-red-300 text-white"
                : violation.severity === "high"
                  ? "bg-orange-500 border-orange-300 text-white"
                  : violation.severity === "medium"
                    ? "bg-yellow-500 border-yellow-300 text-black"
                    : "bg-blue-500 border-blue-300 text-white"
            }
          `}
          >
            !
          </div>
          <div className="absolute top-10 left-1/2 transform -translate-x-1/2 bg-black/80 text-white px-2 py-1 rounded text-xs whitespace-nowrap">
            {violation.type} ({Math.round(violation.confidence * 100)}%)
          </div>
        </div>
      ))}
    </div>
  )
}
