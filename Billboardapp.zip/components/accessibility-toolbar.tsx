"use client"

import { useEffect } from "react"

import { useState } from "react"

export default function AccessibilityToolbar() {
  const [fontSize, setFontSize] = useState("normal")
  const [highContrast, setHighContrast] = useState(false)
  const [voiceEnabled, setVoiceEnabled] = useState(false)
  const [language, setLanguage] = useState("en")

  useEffect(() => {
    // Apply font size changes
    document.documentElement.style.fontSize =
      fontSize === "large" ? "1.2rem" : fontSize === "xlarge" ? "1.4rem" : "1rem"

    // Apply high contrast mode
    if (highContrast) {
      document.documentElement.classList.add("high-contrast")
    } else {
      document.documentElement.classList.remove("high-contrast")
    }
  }, [fontSize, highContrast])

  const speak = (text: string) => {
    if (voiceEnabled && "speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = language === "hi" ? "hi-IN" : "en-US"
      speechSynthesis.speak(utterance)
    }
  }

  return (
    <div className="bg-blue-50 border-b border-blue-200 p-3">
      <div className="flex flex-wrap items-center gap-4 text-sm">
        <div className="flex items-center gap-2">
          <label htmlFor="font-size" className="font-medium">
            Text Size:
          </label>
          <select
            id="font-size"
            value={fontSize}
            onChange={(e) => setFontSize(e.target.value)}
            className="border rounded px-2 py-1"
            aria-label="Adjust text size for better readability"
          >
            <option value="normal">Normal</option>
            <option value="large">Large</option>
            <option value="xlarge">Extra Large</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="high-contrast"
            checked={highContrast}
            onChange={(e) => setHighContrast(e.target.checked)}
            className="rounded"
          />
          <label htmlFor="high-contrast" className="font-medium">
            High Contrast
          </label>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="voice-enabled"
            checked={voiceEnabled}
            onChange={(e) => setVoiceEnabled(e.target.checked)}
            className="rounded"
          />
          <label htmlFor="voice-enabled" className="font-medium">
            Voice Feedback
          </label>
        </div>

        <div className="flex items-center gap-2">
          <label htmlFor="language" className="font-medium">
            Language:
          </label>
          <select
            id="language"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="border rounded px-2 py-1"
            aria-label="Select interface language"
          >
            <option value="en">English</option>
            <option value="hi">हिंदी</option>
          </select>
        </div>
      </div>
    </div>
  )
}
