"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Shield, Eye, Database, Users, Lock, AlertTriangle } from "lucide-react"

interface PrivacyConsentModalProps {
  isOpen: boolean
  onAccept: () => void
  onDecline: () => void
}

export function PrivacyConsentModal({ isOpen, onAccept, onDecline }: PrivacyConsentModalProps) {
  const [consents, setConsents] = useState({
    dataCollection: false,
    imageProcessing: false,
    locationData: false,
    analytics: false,
  })

  const allConsentsGiven = Object.values(consents).every(Boolean)

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <Card className="max-w-2xl w-full max-h-[90vh]">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 p-3 bg-cyan-100 rounded-full w-fit">
            <Shield className="h-8 w-8 text-cyan-600" />
          </div>
          <CardTitle className="text-2xl">Privacy & Data Protection</CardTitle>
          <CardDescription>
            Your privacy is our priority. Please review and consent to our data practices.
          </CardDescription>
        </CardHeader>

        <CardContent>
          <ScrollArea className="h-96 pr-4">
            <div className="space-y-6">
              {/* Data Collection Notice */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-cyan-600" />
                  <h3 className="font-semibold">Data Collection & Usage</h3>
                </div>
                <div className="text-sm text-gray-600 space-y-2">
                  <p>We collect the following data to improve billboard compliance monitoring:</p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Photos/videos of billboards for AI analysis</li>
                    <li>Location data (GPS coordinates) for violation mapping</li>
                    <li>Device information for technical optimization</li>
                    <li>Usage analytics for service improvement</li>
                  </ul>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="dataCollection"
                    checked={consents.dataCollection}
                    onCheckedChange={(checked) => setConsents((prev) => ({ ...prev, dataCollection: !!checked }))}
                  />
                  <label htmlFor="dataCollection" className="text-sm font-medium">
                    I consent to data collection for billboard compliance monitoring
                  </label>
                </div>
              </div>

              {/* AI Processing */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Eye className="h-5 w-5 text-cyan-600" />
                  <h3 className="font-semibold">AI Image Processing</h3>
                </div>
                <div className="text-sm text-gray-600 space-y-2">
                  <p>Our AI system analyzes images to detect:</p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Billboard size and dimensions</li>
                    <li>Location compliance (proximity to roads, buildings)</li>
                    <li>Content appropriateness and permit visibility</li>
                    <li>Structural safety indicators</li>
                  </ul>
                  <div className="bg-amber-50 p-3 rounded-lg border border-amber-200">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="h-4 w-4 text-amber-600 mt-0.5" />
                      <div className="text-xs text-amber-800">
                        <strong>No Facial Recognition:</strong> Our AI does not identify, track, or store facial data of
                        individuals.
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="imageProcessing"
                    checked={consents.imageProcessing}
                    onCheckedChange={(checked) => setConsents((prev) => ({ ...prev, imageProcessing: !!checked }))}
                  />
                  <label htmlFor="imageProcessing" className="text-sm font-medium">
                    I consent to AI analysis of uploaded images (no facial recognition)
                  </label>
                </div>
              </div>

              {/* Location Data */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-cyan-600" />
                  <h3 className="font-semibold">Location & Community Data</h3>
                </div>
                <div className="text-sm text-gray-600 space-y-2">
                  <p>Location data helps authorities:</p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Identify violation hotspots and patterns</li>
                    <li>Coordinate enforcement activities</li>
                    <li>Generate community compliance reports</li>
                    <li>Improve urban planning decisions</li>
                  </ul>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="locationData"
                    checked={consents.locationData}
                    onCheckedChange={(checked) => setConsents((prev) => ({ ...prev, locationData: !!checked }))}
                  />
                  <label htmlFor="locationData" className="text-sm font-medium">
                    I consent to location data collection for compliance mapping
                  </label>
                </div>
              </div>

              {/* Analytics */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-cyan-600" />
                  <h3 className="font-semibold">Data Security & Retention</h3>
                </div>
                <div className="text-sm text-gray-600 space-y-2">
                  <p>Your data is protected through:</p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>End-to-end encryption for all uploads</li>
                    <li>Automatic data deletion after 2 years</li>
                    <li>No sharing with third parties without consent</li>
                    <li>Right to request data deletion anytime</li>
                  </ul>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="analytics"
                    checked={consents.analytics}
                    onCheckedChange={(checked) => setConsents((prev) => ({ ...prev, analytics: !!checked }))}
                  />
                  <label htmlFor="analytics" className="text-sm font-medium">
                    I understand data security measures and retention policies
                  </label>
                </div>
              </div>

              {/* Contact Information */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Data Protection Contact</h4>
                <p className="text-sm text-gray-600">
                  For privacy concerns or data deletion requests, contact:
                  <br />
                  <strong>privacy@billboardwatch.gov.in</strong>
                  <br />
                  Data Protection Officer: +91-XXXX-XXXXXX
                </p>
              </div>
            </div>
          </ScrollArea>

          <div className="flex gap-3 mt-6">
            <Button variant="outline" onClick={onDecline} className="flex-1 bg-transparent">
              Decline
            </Button>
            <Button onClick={onAccept} disabled={!allConsentsGiven} className="flex-1 bg-cyan-600 hover:bg-cyan-700">
              Accept & Continue
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
